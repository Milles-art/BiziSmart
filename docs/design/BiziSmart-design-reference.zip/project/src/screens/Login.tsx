import { useState } from 'react';
import { Store, Phone, KeyRound, AlertCircle, Lock } from 'lucide-react';
import type { Store as StoreType } from '@/store/useStore';

interface Props {
  store: StoreType;
}

export function Login({ store }: Props) {
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = () => {
    setError('');
    setLoading(true);
    setTimeout(() => {
      const success = store.login(phone, pin);
      if (!success) {
        setError('Invalid phone number or PIN. Please try again.');
        setLoading(false);
      }
    }, 400);
  };

  const handleQuickFill = (p: string, pn: string) => {
    setPhone(p);
    setPin(pn);
    setError('');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500 shadow-lg shadow-emerald-500/30">
            <Store className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">BiziSmart</h1>
          <p className="text-sm text-slate-400">Supermarket POS System</p>
        </div>

        <div className="rounded-2xl bg-white p-7 shadow-2xl">
          <h2 className="mb-1 text-lg font-bold text-slate-800">Sign In</h2>
          <p className="mb-5 text-sm text-slate-500">Enter your phone number and PIN to continue</p>

          {error && (
            <div className="mb-4 flex items-center gap-2 rounded-lg bg-red-50 p-3 text-sm text-red-600">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">Phone Number</label>
              <div className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2.5 focus-within:border-emerald-400">
                <Phone className="h-4 w-4 text-slate-400" />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0712345678"
                  className="flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-300"
                  onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                />
              </div>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">4-digit PIN</label>
              <div className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2.5 focus-within:border-emerald-400">
                <KeyRound className="h-4 w-4 text-slate-400" />
                <input
                  type="password"
                  maxLength={4}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="••••"
                  className="flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-300"
                  onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                />
              </div>
            </div>
          </div>

          <button
            onClick={handleLogin}
            disabled={loading || !phone || !pin}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white transition-all hover:bg-emerald-600 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {loading ? (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
            ) : (
              <>
                <Lock className="h-4 w-4" /> Sign In
              </>
            )}
          </button>

          <div className="mt-6 border-t border-slate-100 pt-4">
            <p className="mb-2 text-xs font-medium text-slate-400">Quick demo login:</p>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => handleQuickFill('0711001100','1234')} className="rounded-lg bg-slate-100 p-2 text-left hover:bg-slate-200">
                <p className="text-xs font-semibold text-slate-700">Owner</p>
                <p className="text-[10px] text-slate-400">John Mwangi</p>
              </button>
              <button onClick={() => handleQuickFill('0711002200','2345')} className="rounded-lg bg-slate-100 p-2 text-left hover:bg-slate-200">
                <p className="text-xs font-semibold text-slate-700">Manager</p>
                <p className="text-[10px] text-slate-400">Lucy Wambui</p>
              </button>
              <button onClick={() => handleQuickFill('0711003300','3456')} className="rounded-lg bg-slate-100 p-2 text-left hover:bg-slate-200">
                <p className="text-xs font-semibold text-slate-700">Supervisor</p>
                <p className="text-[10px] text-slate-400">Peter Kamau</p>
              </button>
              <button onClick={() => handleQuickFill('0711004400','4567')} className="rounded-lg bg-slate-100 p-2 text-left hover:bg-slate-200">
                <p className="text-xs font-semibold text-slate-700">Cashier</p>
                <p className="text-[10px] text-slate-400">Mary Atieno</p>
              </button>
            </div>
          </div>
        </div>

        <p className="mt-4 text-center text-xs text-slate-500">
          BiziSmart Supermarket · English / Kiswahili
        </p>
      </div>
    </div>
  );
}

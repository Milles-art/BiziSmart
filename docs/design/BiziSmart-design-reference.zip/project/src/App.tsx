import { useStore } from '@/store/useStore';
import { Login } from '@/screens/Login';
import { Sidebar } from '@/components/layout/Sidebar';
import { TopBar } from '@/components/layout/TopBar';
import { Dashboard } from '@/screens/Dashboard';
import { POS } from '@/screens/POS';
import { Products } from '@/screens/Products';
import { Inventory } from '@/screens/Inventory';
import { Suppliers } from '@/screens/Suppliers';
import { Tills } from '@/screens/Tills';
import { Customers } from '@/screens/Customers';
import { StaffScreen } from '@/screens/StaffScreen';
import { Reports } from '@/screens/Reports';
import { Settings } from '@/screens/Settings';
import { Lock } from 'lucide-react';
import { useState } from 'react';
import type { Screen } from '@/types';

export default function App() {
  const store = useStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (!store.currentUser) {
    return <Login store={store} />;
  }

  const screen = store.screen;

  const renderScreen = () => {
    if (!store.canAccessScreen(screen)) {
      return (
        <div className="flex flex-col items-center justify-center p-16 text-center">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-red-100">
            <Lock className="h-8 w-8 text-red-500" />
          </div>
          <h2 className="text-lg font-bold text-slate-800">Access Denied</h2>
          <p className="mt-1 text-sm text-slate-500">Your role ({store.currentUser!.role}) does not have access to this screen.</p>
          <button onClick={() => store.setScreen('pos')} className="mt-4 rounded-lg bg-emerald-500 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-600">
            Go to Point of Sale
          </button>
        </div>
      );
    }
    switch (screen) {
      case 'dashboard': return <Dashboard store={store} />;
      case 'pos': return <POS store={store} />;
      case 'products': return <Products store={store} />;
      case 'inventory': return <Inventory store={store} />;
      case 'suppliers': return <Suppliers store={store} />;
      case 'tills': return <Tills store={store} />;
      case 'customers': return <Customers store={store} />;
      case 'staff': return <StaffScreen store={store} />;
      case 'reports': return <Reports store={store} />;
      case 'settings': return <Settings store={store} />;
      default: return <Dashboard store={store} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-100">
      <Sidebar
        screen={screen}
        onNavigate={(s: Screen) => { store.setScreen(s); setSidebarOpen(false); }}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        store={store}
      />
      <div className="flex flex-1 flex-col overflow-hidden">
        <TopBar screen={screen} onMenuClick={() => setSidebarOpen(true)} store={store} />
        <main className="flex-1 overflow-y-auto">
          {renderScreen()}
        </main>
      </div>
    </div>
  );
}

import { ShoppingCart, DollarSign, Users, Package, AlertTriangle, Clock, ArrowRight, TrendingUp, TrendingDown, Shield, Calculator } from 'lucide-react';
import { StatCard, SectionCard, Badge } from '@/components/ui/Primitives';
import { formatKES } from '@/store/useStore';
import type { Store as StoreType } from '@/store/useStore';
import type { Screen } from '@/types';

interface Props { store: StoreType; }

export function Dashboard({ store }: Props) {
  const { todaySales, lowStockProducts, expiringProducts, transactions, tills, pendingApprovals, weeklySalesData } = store;
  const openTills = tills.filter(t => t.status === 'open');
  const varianceTills = tills.filter(t => t.variance !== 0);
  const notifications: { id: string; type: 'warning' | 'danger' | 'info'; title: string; message: string; time: string; screen: Screen; icon: 'package' | 'clock' | 'shield' | 'calculator' }[] = [
    ...(lowStockProducts.length > 0 ? [{ id:'n1', type:'warning' as const, title:'Low Stock', message:`${lowStockProducts.length} products below reorder level`, time:'5 min ago', screen:'inventory' as Screen, icon:'package' as const }] : []),
    ...(expiringProducts.length > 0 ? [{ id:'n2', type:'danger' as const, title:'Near Expiry', message:`${expiringProducts.length} products expiring within 7 days`, time:'12 min ago', screen:'inventory' as Screen, icon:'clock' as const }] : []),
    ...(pendingApprovals.length > 0 ? [{ id:'n3', type:'info' as const, title:'Pending Approvals', message:`${pendingApprovals.length} requests awaiting supervisor`, time:'now', screen:'tills' as Screen, icon:'shield' as const }] : []),
    ...(varianceTills.length > 0 ? [{ id:'n4', type:'info' as const, title:`${varianceTills[0].name} Variance`, message:`Cash variance of ${formatKES(Math.abs(varianceTills[0].variance))} detected`, time:'25 min ago', screen:'tills' as Screen, icon:'calculator' as const }] : []),
  ];

  return (
    <div className="space-y-6 p-4 lg:p-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="Today's Sales" value={formatKES(todaySales.total)} change={`${todaySales.count} txns`} trend="up" icon={<DollarSign className="h-5 w-5 text-white" />} color="bg-emerald-500" />
        <StatCard title="Gross Profit Today" value={formatKES(todaySales.grossProfit)} change={`${((todaySales.grossProfit/todaySales.total)*100||0).toFixed(1)}% margin`} trend="up" icon={<TrendingUp className="h-5 w-5 text-white" />} color="bg-blue-500" />
        <StatCard title="Cash + M-Pesa" value={formatKES(todaySales.cashTotal + todaySales.mpesaTotal)} icon={<ShoppingCart className="h-5 w-5 text-white" />} color="bg-violet-500" />
        <StatCard title="Low Stock Items" value={String(lowStockProducts.length)} change="Needs attention" trend="down" icon={<Package className="h-5 w-5 text-white" />} color="bg-amber-500" />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <SectionCard title="Weekly Sales Trend" className="lg:col-span-2" action={<span className="text-xs text-slate-400">Last 7 days</span>}>
          <div className="flex items-end justify-between gap-2 sm:gap-4" style={{ height:'220px' }}>
            {weeklySalesData.map(day => {
              const max = Math.max(...weeklySalesData.map(d => d.totalSales), 1);
              const heightPct = (day.totalSales / max) * 100;
              return (
                <div key={day.date} className="flex flex-1 flex-col items-center gap-2">
                  <span className="text-[10px] font-semibold text-slate-500">{day.totalSales > 0 ? `${(day.totalSales/1000).toFixed(0)}K` : '—'}</span>
                  <div className="flex w-full flex-1 items-end"><div className="w-full rounded-t-md bg-gradient-to-t from-emerald-500 to-emerald-400 transition-all hover:from-emerald-600 hover:to-emerald-500" style={{ height:`${Math.max(heightPct, 2)}%` }} /></div>
                  <span className="text-[10px] text-slate-400">{day.label}</span>
                </div>
              );
            })}
          </div>
        </SectionCard>

        <SectionCard title="Alerts & Notifications" action={<button onClick={() => store.setScreen('tills')} className="flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-700">Resolve <ArrowRight className="h-3 w-3" /></button>}>
          <div className="space-y-2">
            {notifications.length === 0 ? (
              <div className="flex items-center gap-3 rounded-lg bg-emerald-50 p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100"><TrendingUp className="h-4 w-4 text-emerald-600" /></div>
                <p className="text-sm text-emerald-600">All clear — no alerts</p>
              </div>
            ) : notifications.map(n => {
              const iconMap = { package: Package, clock: Clock, shield: Shield, calculator: Calculator };
              const Icon = iconMap[n.icon];
              return (
                <button key={n.id} onClick={() => store.setScreen(n.screen)} className="flex w-full items-start gap-3 rounded-lg p-2 text-left transition-colors hover:bg-slate-50">
                  <div className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${n.type==='danger'?'bg-red-100':n.type==='warning'?'bg-amber-100':'bg-blue-100'}`}>
                    <Icon className={`h-4 w-4 ${n.type==='danger'?'text-red-600':n.type==='warning'?'text-amber-600':'text-blue-600'}`} />
                  </div>
                  <div className="min-w-0 flex-1"><p className="text-sm font-medium text-slate-700">{n.title}</p><p className="text-xs text-slate-500">{n.message}</p><p className="mt-0.5 text-[10px] text-slate-400">{n.time} · Tap to resolve</p></div>
                  <ArrowRight className="mt-1 h-4 w-4 shrink-0 text-slate-300" />
                </button>
              );
            })}
          </div>
        </SectionCard>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <SectionCard title="Recent Transactions" className="lg:col-span-2" action={<button onClick={() => store.setScreen('tills')} className="flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-700">View all <ArrowRight className="h-3 w-3" /></button>}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-slate-100 text-left text-xs text-slate-400"><th className="pb-2 font-medium">Receipt</th><th className="pb-2 font-medium">Time</th><th className="pb-2 font-medium">Cashier</th><th className="pb-2 font-medium">Method</th><th className="pb-2 text-right font-medium">Total</th><th className="pb-2 text-center font-medium">Status</th></tr></thead>
              <tbody className="divide-y divide-slate-50">
                {transactions.slice(0, 7).map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-50">
                    <td className="py-2.5 font-medium text-slate-700">{tx.receiptNo}</td>
                    <td className="py-2.5 text-slate-500">{tx.time}</td>
                    <td className="py-2.5 text-slate-600">{tx.cashier}</td>
                    <td className="py-2.5 capitalize text-slate-600">{tx.method}</td>
                    <td className="py-2.5 text-right font-semibold text-slate-700">{tx.status==='voided'||tx.status==='held'?'—':formatKES(tx.total)}</td>
                    <td className="py-2.5 text-center"><Badge status={tx.status} variant={tx.status==='completed'?'success':tx.status==='held'?'warning':tx.status==='refunded'?'info':tx.status==='partial_refund'?'warning':'danger'} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>

        <SectionCard title="Till Status" action={<button onClick={() => store.setScreen('tills')} className="flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-700">Manage <ArrowRight className="h-3 w-3" /></button>}>
          <div className="space-y-3">
            {openTills.map(till => (
              <div key={till.id} className="flex items-center justify-between rounded-lg border border-slate-100 p-3 hover:border-slate-200">
                <div><p className="text-sm font-semibold text-slate-700">{till.name}</p><p className="text-xs text-slate-500">{till.cashier}</p></div>
                <div className="text-right"><p className="text-sm font-bold text-slate-800">{formatKES(till.cashSales + till.mpesaSales)}</p><p className="text-xs text-slate-400">{till.transactions} txns · {till.voids} voids</p></div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <SectionCard title="Low Stock Alerts" action={<button onClick={() => store.setScreen('inventory')} className="flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-700">Restock <ArrowRight className="h-3 w-3" /></button>}>
          <div className="space-y-2">
            {lowStockProducts.slice(0, 5).map(p => (
              <button key={p.id} onClick={() => store.setScreen('inventory')} className="flex w-full items-center justify-between rounded-lg p-2.5 text-left hover:bg-slate-50">
                <div className="flex items-center gap-3"><div className={`h-8 w-8 rounded-lg ${p.imageColor}`} /><div><p className="text-sm font-medium text-slate-700">{p.name}</p><p className="text-xs text-slate-400">{p.department}</p></div></div>
                <div className="text-right"><p className="text-sm font-semibold text-red-600">{p.stock} {p.unit}</p><p className="text-xs text-slate-400">Min: {p.reorderLevel}</p></div>
              </button>
            ))}
            {lowStockProducts.length === 0 && <p className="py-4 text-center text-sm text-slate-400">All products well stocked</p>}
          </div>
        </SectionCard>

        <SectionCard title="Near-Expiry Products" action={<button onClick={() => store.setScreen('inventory')} className="flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-700">Review <ArrowRight className="h-3 w-3" /></button>}>
          <div className="space-y-2">
            {expiringProducts.slice(0, 5).map(p => {
              const days = Math.ceil((new Date(p.expiry!).getTime() - new Date('2026-10-08').getTime()) / (1000*60*60*24));
              return (
                <button key={p.id} onClick={() => store.setScreen('inventory')} className="flex w-full items-center justify-between rounded-lg p-2.5 text-left hover:bg-slate-50">
                  <div className="flex items-center gap-3"><div className={`h-8 w-8 rounded-lg ${p.imageColor}`} /><div><p className="text-sm font-medium text-slate-700">{p.name}</p><p className="text-xs text-slate-400">Batch: {p.batch}</p></div></div>
                  <Badge status={`${days} day${days!==1?'s':''} left`} variant={days<=2?'danger':'warning'} />
                </button>
              );
            })}
            {expiringProducts.length === 0 && <p className="py-4 text-center text-sm text-slate-400">No products expiring soon</p>}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}

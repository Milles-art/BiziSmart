export type Currency = 'TZS';

export type Language = 'en' | 'sw';

export type Role = 'Cashier' | 'Supervisor' | 'Manager' | 'Owner' | 'Admin';

export type Permission =
  | 'pos' | 'products' | 'inventory' | 'suppliers'
  | 'tills' | 'customers' | 'staff' | 'reports' | 'settings'
  | 'refund' | 'void' | 'discount' | 'approve' | 'manage_till'
  | 'price_change' | 'stock_adjust' | 'markdown'
  | 'expenses' | 'banking' | 'messaging' | 'offline' | 'admin';

export interface Product {
  id: string;
  name: string;
  barcode: string;
  category: string;
  department: string;
  price: number;
  cost: number;
  unit: 'each' | 'kg' | 'pack' | 'carton';
  stock: number;
  reorderLevel: number;
  expiry?: string;
  batch?: string;
  taxable: boolean;
  imageColor: string;
  imageUrl?: string;
  packSize?: number;
  packPrice?: number;
  cartonSize?: number;
  cartonPrice?: number;
  weighed?: boolean;
  scaleBarcode?: string;
  priceHistory?: { date: string; price: number; user: string }[];
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  qty: number;
  unit: string;
  discount: number;
  weighed: boolean;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  creditLimit: number;
  debt: number;
  totalSpent: number;
  joinedDate: string;
  loyaltyPoints: number;
  loyaltyConsent: boolean;
  whatsappConsent: boolean;
  qrCode?: string;
  debtHistory?: { id: string; date: string; description: string; amount: number; type: 'debt' | 'payment' }[];
}

export interface Supplier {
  id: string;
  name: string;
  contact: string;
  phone: string;
  email: string;
  balance: number;
  lastOrder: string;
  products: number;
  priceHistory: { productId: string; date: string; price: number }[];
  statements?: { id: string; date: string; description: string; debit: number; credit: number; balance: number }[];
  paymentSchedule?: { id: string; poId: string; amount: number; dueDate: string; status: 'pending' | 'paid' | 'overdue' }[];
}

export interface PurchaseOrderItem {
  productId: string;
  name: string;
  qty: number;
  cost: number;
  total: number;
  batch?: string;
  expiry?: string;
}

export interface PurchaseOrder {
  id: string;
  supplierId: string;
  supplierName: string;
  date: string;
  expected: string;
  status: 'draft' | 'sent' | 'received' | 'partial';
  total: number;
  items: PurchaseOrderItem[];
  paymentTerms: string;
  paymentStatus: 'unpaid' | 'partial' | 'paid';
  paymentDue?: string;
}

export interface Staff {
  id: string;
  name: string;
  role: Role;
  phone: string;
  pin: string;
  active: boolean;
  salesToday: number;
  attendance: 'present' | 'absent' | 'leave';
  twoFactor: boolean;
  clockInTime?: string;
  commissionRate?: number;
  notifications?: { id: string; title: string; message: string; time: string; read: boolean; type: 'approval' | 'system' | 'incentive' }[];
}

export interface CashDrop {
  id: string;
  tillId: string;
  amount: number;
  time: string;
  acknowledged: boolean;
  acknowledgedBy?: string;
}

export interface PaidOut {
  id: string;
  tillId: string;
  amount: number;
  reason: string;
  time: string;
  user: string;
}

export interface Till {
  id: string;
  name: string;
  cashierId: string | null;
  cashier: string;
  status: 'open' | 'closed' | 'suspended';
  openingFloat: number;
  closingFloat: number | null;
  cashSales: number;
  mpesaSales: number;
  creditSales: number;
  transactions: number;
  voids: number;
  variance: number;
  cashDrops: CashDrop[];
  paidOuts: PaidOut[];
  openedAt: string | null;
}

export interface Transaction {
  id: string;
  receiptNo: string;
  time: string;
  date: string;
  cashierId: string;
  cashier: string;
  tillId: string;
  tillName: string;
  items: CartItem[];
  total: number;
  subtotal: number;
  tax: number;
  discount: number;
  method: 'cash' | 'mpesa' | 'credit' | 'split';
  cashAmount?: number;
  mpesaAmount?: number;
  mpesaRef?: string;
  customer?: string;
  customerId?: string;
  status: 'completed' | 'held' | 'refunded' | 'voided' | 'partial_refund' | 'quarantined';
  refundAmount?: number;
  cost: number;
  offline?: boolean;
  synced?: boolean;
}

export interface Approval {
  id: string;
  type: 'refund' | 'void' | 'discount' | 'stock_adjust' | 'price_change' | 'markdown' | 'expense' | 'quarantine';
  description: string;
  amount?: number;
  requestedBy: string;
  requestedAt: string;
  status: 'pending' | 'approved' | 'denied';
  approvedBy?: string;
  transactionId?: string;
  data?: Record<string, unknown>;
}

export interface StockMovement {
  id: string;
  productId: string;
  productName: string;
  type: 'Sale' | 'Received' | 'Wastage' | 'Damage' | 'Spoilage' | 'Adjustment' | 'Return' | 'Transfer' | 'Count';
  qty: number;
  user: string;
  time: string;
  reason: string;
  approved: boolean;
  batch?: string;
}

export interface PriceChange {
  id: string;
  productId: string;
  productName: string;
  oldPrice: number;
  newPrice: number;
  date: string;
  user: string;
  scheduled?: string;
  applied: boolean;
}

export interface Promotion {
  id: string;
  name: string;
  type: 'percentage' | 'fixed' | 'bxgy' | 'bulk' | 'time';
  value: number;
  buyQty?: number;
  getQty?: number;
  productId?: string;
  category?: string;
  active: boolean;
  startDate: string;
  endDate: string;
}

export interface AuditEntry {
  id: string;
  action: string;
  user: string;
  time: string;
  type: 'approval' | 'void' | 'discount' | 'adjustment' | 'cash' | 'till' | 'login' | 'refund' | 'price_change' | 'expense' | 'offline' | 'messaging' | 'admin';
}

export interface MpesaPayment {
  id: string;
  phone: string;
  amount: number;
  ref: string;
  time: string;
  matched: boolean;
  transactionId?: string;
}

export interface HeldSale {
  id: string;
  items: CartItem[];
  time: string;
  total: number;
}

export interface StockTakeItem {
  productId: string;
  productName: string;
  systemQty: number;
  countedQty: number | null;
  variance: number;
}

export interface StockTake {
  id: string;
  department: string;
  countedBy: string;
  startedAt: string;
  status: 'in_progress' | 'completed';
  items: StockTakeItem[];
}

export interface SaleSummary {
  date: string;
  totalSales: number;
  transactions: number;
  avgBasket: number;
  cashSales: number;
  mpesaSales: number;
  creditSales: number;
  topProducts: { name: string; qty: number; revenue: number }[];
}

// --- New types for expanded features ---

export interface BankAccount {
  id: string;
  name: string;
  bank: string;
  accountNumber: string;
  balance: number;
  entries: BankEntry[];
}

export interface BankEntry {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  reconciled: boolean;
  imported?: boolean;
}

export interface Expense {
  id: string;
  category: string;
  description: string;
  amount: number;
  date: string;
  user: string;
  tillId?: string;
  photoUrl?: string;
  status: 'pending' | 'approved' | 'denied';
  approvedBy?: string;
}

export interface MessageLog {
  id: string;
  type: 'whatsapp' | 'sms';
  recipient: string;
  recipientName: string;
  content: string;
  time: string;
  status: 'sent' | 'failed' | 'pending' | 'uncertain';
  providerUnavailable?: boolean;
  category: 'receipt' | 'promotion' | 'reminder' | 'statement';
}

export interface NotificationSetting {
  receipts: boolean;
  promotions: boolean;
  debtReminders: boolean;
  statements: boolean;
  lowStockAlerts: boolean;
}

export interface OfflineOperation {
  id: string;
  type: 'sale' | 'refund' | 'void' | 'stock_adjust';
  description: string;
  time: string;
  status: 'pending' | 'synced' | 'conflict' | 'uncertain';
  data: Record<string, unknown>;
  retryCount: number;
}

export interface SuspiciousActivity {
  id: string;
  type: 'void_spike' | 'discount_abuse' | 'refund_spike' | 'cash_variance' | 'after_hours' | 'manual_override';
  description: string;
  user: string;
  time: string;
  severity: 'low' | 'medium' | 'high';
  resolved: boolean;
}

export interface LossThreshold {
  voidLimit: number;
  refundLimit: number;
  discountLimit: number;
  varianceLimit: number;
  afterHoursStart: string;
}

export interface CommissionSetting {
  staffId: string;
  staffName: string;
  rate: number;
  target: number;
  earned: number;
}

export interface Incentive {
  id: string;
  name: string;
  description: string;
  type: 'sales_target' | 'demand' | 'slow_mover';
  target: number;
  reward: number;
  active: boolean;
  leaderboard: { staffId: string; staffName: string; progress: number; rank: number }[];
}

export interface AdminClient {
  id: string;
  businessName: string;
  ownerName: string;
  phone: string;
  plan: 'Starter' | 'Business' | 'Enterprise';
  status: 'active' | 'trial' | 'suspended' | 'expired';
  features: string[];
  healthScore: number;
  lastActive: string;
  staffCount: number;
  monthlyRevenue: number;
  subscriptionStatus: 'paid' | 'complimentary' | 'overdue';
  createdAt: string;
}

export interface ImportExportRow {
  row: number;
  data: Record<string, string>;
  errors: string[];
  valid: boolean;
}

export interface Device {
  id: string;
  name: string;
  device: string;
  lastActive: string;
  status: 'Active' | 'Offline' | 'Pending';
  approved: boolean;
}

export type Screen =
  | 'dashboard' | 'pos' | 'products' | 'inventory' | 'suppliers'
  | 'tills' | 'customers' | 'staff' | 'reports' | 'settings'
  | 'banking' | 'messaging' | 'offline' | 'admin';

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  Owner: ['pos','products','inventory','suppliers','tills','customers','staff','reports','settings','refund','void','discount','approve','manage_till','price_change','stock_adjust','markdown','expenses','banking','messaging','offline'],
  Manager: ['pos','products','inventory','suppliers','tills','customers','staff','reports','refund','void','discount','approve','manage_till','price_change','stock_adjust','markdown','expenses','banking','messaging','offline'],
  Supervisor: ['pos','products','inventory','suppliers','tills','customers','reports','void','discount','approve','manage_till','stock_adjust','expenses'],
  Cashier: ['pos','customers'],
  Admin: ['admin'],
};

// --- i18n ---
export const translations: Record<Language, Record<string, string>> = {
  en: {
    'nav.dashboard': 'Dashboard',
    'nav.pos': 'Point of Sale',
    'nav.products': 'Products',
    'nav.inventory': 'Inventory',
    'nav.suppliers': 'Suppliers',
    'nav.tills': 'Tills & Cash',
    'nav.customers': 'Customers',
    'nav.staff': 'Staff',
    'nav.reports': 'Reports',
    'nav.settings': 'Settings',
    'nav.banking': 'Banking',
    'nav.messaging': 'Messaging',
    'nav.offline': 'Offline Sync',
    'nav.admin': 'Platform Admin',
    'common.total': 'Total',
    'common.subtotal': 'Subtotal',
    'common.tax': 'Tax',
    'common.discount': 'Discount',
    'common.search': 'Search',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.approve': 'Approve',
    'common.deny': 'Deny',
    'common.loading': 'Loading...',
    'common.empty': 'No data available',
    'common.error': 'Something went wrong',
    'common.print': 'Print',
    'common.export': 'Export',
    'login.title': 'Sign In',
    'login.subtitle': 'Enter your phone number and PIN to continue',
    'login.phone': 'Phone Number',
    'login.pin': '4-digit PIN',
    'login.button': 'Sign In',
    'pos.checkout': 'Checkout',
    'pos.cart_empty': 'Cart is empty',
    'pos.held_sales': 'Held Sales',
    'settings.language': 'Language & Localization',
    'settings.currency': 'Currency',
  },
  sw: {
    'nav.dashboard': 'Dashibodi',
    'nav.pos': 'Sehemu ya Kuuza',
    'nav.products': 'Bidhaa',
    'nav.inventory': 'Hifadhi',
    'nav.suppliers': 'Wasambazaji',
    'nav.tills': 'Kasha na Fedha',
    'nav.customers': 'Wateja',
    'nav.staff': 'Wafanyakazi',
    'nav.reports': 'Ripoti',
    'nav.settings': 'Mipangilio',
    'nav.banking': 'Benki',
    'nav.messaging': 'Ujumbe',
    'nav.offline': 'Usawazishaji',
    'nav.admin': 'Usimamizi wa Jukwaa',
    'common.total': 'Jumla',
    'common.subtotal': 'Jumla ndogo',
    'common.tax': 'Kodi',
    'common.discount': 'Punguzo',
    'common.search': 'Tafuta',
    'common.save': 'Hifadhi',
    'common.cancel': 'Ghairi',
    'common.approve': 'Idhini',
    'common.deny': 'Kataa',
    'common.loading': 'Inapakia...',
    'common.empty': 'Hakuna data',
    'common.error': 'Hitilafu imetokea',
    'common.print': 'Chapa',
    'common.export': 'Hamisha',
    'login.title': 'Ingia',
    'login.subtitle': 'Weka nambari ya simu na PIN yako',
    'login.phone': 'Nambari ya Simu',
    'login.pin': 'PIN tarakimu 4',
    'login.button': 'Ingia',
    'pos.checkout': 'Lipa',
    'pos.cart_empty': 'Kikapu kime tupu',
    'pos.held_sales': 'Mauzo yaliyoshikiliwa',
    'settings.language': 'Lugha na Ujumuishaji',
    'settings.currency': 'Sarafu',
  },
};

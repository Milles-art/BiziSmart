import { useState } from 'react';
import { CloudOff, RefreshCw, CheckCircle, AlertTriangle, Clock, X, Upload, Wifi, WifiOff, Database, Loader2, FileWarning } from 'lucide-react';
import { StatCard, SectionCard, Badge } from '@/components/ui/Primitives';
import { formatKES } from '@/store/useStore';
import type { Store as StoreType } from '@/store/useStore';

interface Props { store: StoreType; }

export function OfflineSync({ store }: Props) {
  const [syncNotice, setSyncNotice] = useState('');
  const [showQuarantine, setShowQuarantine] = useState(false);

  const quarantinedTxns = store.transactions.filter(t => t.status === 'quarantined');
  const pendingOps = store.offlineOps.filter(o => o.status === 'pending');
  const conflictOps = store.offlineOps.filter(o => o.status === 'conflict');
  const uncertainOps = store.offlineOps.filter(o => o.status === 'uncertain');
  const syncedOps = store.offlineOps.filter(o => o.status === 'synced');

  const showNotice = (msg: string) => { setSyncNotice(msg); setTimeout(() => setSyncNotice(''), 3000); };

  const isOnline = store.onlineStatus === 'online';

  return (
    <div className="space-y-5 p-4 lg:p-6">
      {syncNotice && <div className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-600">{syncNotice}</div>}

      {/* Connection Status Banner */}
      <div className={`flex items-center justify-between rounded-xl p-4 ${isOnline ? 'bg-emerald-50' : store.onlineStatus === 'syncing' ? 'bg-blue-50' : 'bg-amber-50'}`}>
        <div className="flex items-center gap-3">
          {isOnline ? <Wifi className="h-6 w-6 text-emerald-600" /> : store.onlineStatus === 'syncing' ? <Loader2 className="h-6 w-6 animate-spin text-blue-600" /> : <WifiOff className="h-6 w-6 text-amber-600" />}
          <div>
            <p className={`text-sm font-bold ${isOnline ? 'text-emerald-700' : store.onlineStatus === 'syncing' ? 'text-blue-700' : 'text-amber-700'}`}>
              {isOnline ? 'Online — All systems connected' : store.onlineStatus === 'syncing' ? 'Syncing — Reconnecting to server...' : 'Offline — Operating in offline mode'}
            </p>
            <p className="text-xs text-slate-500">{isOnline ? 'Changes sync automatically' : 'Cash sales continue offline. Other operations queued for sync.'}</p>
          </div>
        </div>
        {isOnline ? (
          <button onClick={() => store.goOffline()} className="rounded-lg bg-white px-4 py-2 text-sm font-medium text-amber-600 hover:bg-amber-100">Simulate Offline</button>
        ) : (
          <button onClick={() => store.goOnline()} className="flex items-center gap-2 rounded-lg bg-emerald-500 px-4 py-2 text-sm font-bold text-white hover:bg-emerald-600"><RefreshCw className="h-4 w-4" /> Reconnect & Sync</button>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Pending Operations" value={String(pendingOps.length)} icon={<Clock className="h-5 w-5 text-white" />} color="bg-amber-500" />
        <StatCard title="Synced" value={String(syncedOps.length)} icon={<CheckCircle className="h-5 w-5 text-white" />} color="bg-emerald-500" />
        <StatCard title="Conflicts" value={String(conflictOps.length)} icon={<AlertTriangle className="h-5 w-5 text-white" />} color="bg-red-500" />
        <StatCard title="Quarantined Sales" value={String(quarantinedTxns.length)} icon={<FileWarning className="h-5 w-5 text-white" />} color="bg-violet-500" />
      </div>

      <SectionCard title="Pending & Uncertain Operations" action={pendingOps.length > 0 ? <Badge status={`${pendingOps.length} pending`} variant="warning" /> : <Badge status="All synced" variant="success" />}>
        {pendingOps.length === 0 && uncertainOps.length === 0 && conflictOps.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-slate-300">
            <Database className="mb-2 h-10 w-10" />
            <p className="text-sm text-slate-400">No pending operations</p>
            <p className="text-xs text-slate-400">All offline operations have been synced</p>
          </div>
        ) : (
          <div className="space-y-2">
            {[...pendingOps, ...uncertainOps, ...conflictOps].map(op => (
              <div key={op.id} className="flex items-center justify-between rounded-lg border border-slate-100 p-3 hover:bg-slate-50">
                <div className="flex items-center gap-3">
                  <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${op.status === 'conflict' ? 'bg-red-100' : op.status === 'uncertain' ? 'bg-amber-100' : 'bg-blue-100'}`}>
                    {op.status === 'conflict' ? <AlertTriangle className="h-4 w-4 text-red-600" /> : op.status === 'uncertain' ? <Clock className="h-4 w-4 text-amber-600" /> : <Upload className="h-4 w-4 text-blue-600" />}
                  </div>
                  <div>
                    <p className="text-sm font-medium capitalize text-slate-700">{op.type.replace('_', ' ')} — {op.description}</p>
                    <p className="text-xs text-slate-400">{op.time} · Retry #{op.retryCount} · {op.status}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {op.status === 'conflict' ? (
                    <>
                      <button onClick={() => store.resolveConflict(op.id, 'discard')} className="rounded-md bg-red-100 px-3 py-1.5 text-xs font-medium text-red-600 hover:bg-red-200">Discard</button>
                      <button onClick={() => store.resolveConflict(op.id, 'accept')} className="rounded-md bg-emerald-100 px-3 py-1.5 text-xs font-medium text-emerald-600 hover:bg-emerald-200">Accept Local</button>
                    </>
                  ) : (
                    <button onClick={() => store.retryOfflineOp(op.id)} className="flex items-center gap-1 rounded-md bg-blue-100 px-3 py-1.5 text-xs font-medium text-blue-600 hover:bg-blue-200"><RefreshCw className="h-3 w-3" /> Retry</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      <SectionCard title="Quarantined Sales Review" action={<button onClick={() => setShowQuarantine(true)} className="text-xs font-medium text-emerald-600 hover:text-emerald-700">Review All</button>}>
        <div className="rounded-lg bg-amber-50 p-3 text-xs text-amber-700 mb-3">Quarantined sales are offline transactions that could not be verified against the server. The owner must review and approve or discard them.</div>
        {quarantinedTxns.length === 0 ? (
          <p className="py-4 text-center text-sm text-slate-400">No quarantined sales</p>
        ) : (
          <div className="space-y-2">
            {quarantinedTxns.slice(0, 5).map(txn => (
              <div key={txn.id} className="flex items-center justify-between rounded-lg border border-slate-100 p-3">
                <div><p className="text-sm font-mono font-medium text-slate-700">{txn.receiptNo}</p><p className="text-xs text-slate-400">{txn.time} · {txn.items.length} items · {txn.cashier}</p></div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold text-slate-700">{formatKES(txn.total)}</span>
                  <Badge status="Quarantined" variant="danger" />
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      <SectionCard title="Offline Capabilities">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {[
            { name: 'Cash Checkout', desc: 'Process cash sales offline', available: true, icon: '💰' },
            { name: 'Product Lookup', desc: 'Search cached product catalog', available: true, icon: '📦' },
            { name: 'M-Pesa Payment', desc: 'Requires online connection', available: false, icon: '📱' },
            { name: 'Credit Sales', desc: 'Requires online for credit check', available: false, icon: '💳' },
            { name: 'Stock Receiving', desc: 'Queue for sync on reconnect', available: true, icon: '📥' },
            { name: 'Supplier Payments', desc: 'Requires online connection', available: false, icon: '🏦' },
          ].map(cap => (
            <div key={cap.name} className={`flex items-center justify-between rounded-lg border p-3 ${cap.available ? 'border-emerald-100 bg-emerald-50' : 'border-slate-100 bg-slate-50'}`}>
              <div className="flex items-center gap-3">
                <span className="text-2xl">{cap.icon}</span>
                <div><p className="text-sm font-medium text-slate-700">{cap.name}</p><p className="text-xs text-slate-400">{cap.desc}</p></div>
              </div>
              {cap.available ? <CheckCircle className="h-5 w-5 text-emerald-500" /> : <CloudOff className="h-5 w-5 text-slate-300" />}
            </div>
          ))}
        </div>
      </SectionCard>

      {/* Quarantine Review Modal */}
      {showQuarantine && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowQuarantine(false)}>
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><FileWarning className="h-5 w-5 text-amber-500" /><h2 className="text-lg font-bold text-slate-800">Quarantined Sales Review</h2></div><button onClick={() => setShowQuarantine(false)} className="text-slate-400"><X className="h-5 w-5" /></button></div>
            <div className="mb-4 rounded-lg bg-amber-50 p-3 text-xs text-amber-700">Review each quarantined sale. Approved sales will be synced to the server. Discarded sales will be voided and stock restored.</div>
            <div className="space-y-3">
              {quarantinedTxns.length === 0 ? <p className="py-8 text-center text-sm text-slate-400">No quarantined sales to review</p> : quarantinedTxns.map(txn => (
                <div key={txn.id} className="rounded-lg border border-slate-200 p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <p className="font-mono text-sm font-bold text-slate-700">{txn.receiptNo}</p>
                    <Badge status="Quarantined" variant="danger" />
                  </div>
                  <div className="text-xs text-slate-500"><p>{txn.time} · {txn.date} · Cashier: {txn.cashier} · Till: {txn.tillName}</p><p>{txn.items.length} items · Total: {formatKES(txn.total)} · Payment: {txn.method}</p></div>
                  <div className="mt-3 flex gap-2">
                    <button className="flex-1 rounded-lg bg-red-100 py-2 text-sm font-medium text-red-600 hover:bg-red-200">Discard Sale</button>
                    <button onClick={() => showNotice(`Sale ${txn.receiptNo} approved`)} className="flex-1 rounded-lg bg-emerald-500 py-2 text-sm font-bold text-white hover:bg-emerald-600">Approve & Sync</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

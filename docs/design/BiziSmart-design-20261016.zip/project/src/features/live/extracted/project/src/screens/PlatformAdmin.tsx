import { useState } from 'react';
import { ShieldCheck, Plus, Users, Heart, Building2, Crown, Search, MoreVertical, TrendingUp, TrendingDown, X, CheckCircle, Send, Eye } from 'lucide-react';
import { StatCard, SectionCard, Badge } from '@/components/ui/Primitives';
import { formatKES } from '@/store/useStore';
import type { Store as StoreType } from '@/store/useStore';
import type { AdminClient } from '@/types';

interface Props { store: StoreType; }

export function PlatformAdmin({ store }: Props) {
  const [showInvite, setShowInvite] = useState(false);
  const [showClient, setShowClient] = useState<AdminClient | null>(null);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'trial' | 'suspended'>('all');

  const filtered = store.adminClients
    .filter(c => filter === 'all' || c.status === filter)
    .filter(c => !search || c.businessName.toLowerCase().includes(search.toLowerCase()) || c.ownerName.toLowerCase().includes(search.toLowerCase()));

  const activeCount = store.adminClients.filter(c => c.status === 'active').length;
  const trialCount = store.adminClients.filter(c => c.status === 'trial').length;
  const totalRevenue = store.adminClients.reduce((s, c) => s + c.monthlyRevenue, 0);
  const avgHealth = store.adminClients.length > 0 ? Math.round(store.adminClients.reduce((s, c) => s + c.healthScore, 0) / store.adminClients.length) : 0;

  // invite form
  const [invName, setInvName] = useState('');
  const [invBusiness, setInvBusiness] = useState('');
  const [invPhone, setInvPhone] = useState('');
  const [invPlan, setInvPlan] = useState<AdminClient['plan']>('Starter');

  const handleInvite = () => {
    if (!invName || !invBusiness || !invPhone) return;
    store.addAdminClient({
      businessName: invBusiness, ownerName: invName, phone: invPhone,
      plan: invPlan, status: 'trial', features: ['pos', 'inventory'],
      healthScore: 50, lastActive: 'Just now', staffCount: 1,
      monthlyRevenue: 0, subscriptionStatus: 'complimentary',
    });
    setInvName(''); setInvBusiness(''); setInvPhone(''); setInvPlan('Starter');
    setShowInvite(false);
  };

  return (
    <div className="space-y-5 p-4 lg:p-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-6 w-6 text-emerald-500" />
          <h1 className="text-lg font-bold text-slate-800">Platform Administration</h1>
        </div>
        <button onClick={() => setShowInvite(true)} className="flex items-center gap-1.5 rounded-lg bg-emerald-500 px-3 py-2 text-sm font-bold text-white hover:bg-emerald-600"><Plus className="h-4 w-4" /> Invite Client</button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Total Clients" value={String(store.adminClients.length)} icon={<Building2 className="h-5 w-5 text-white" />} color="bg-emerald-500" />
        <StatCard title="Active" value={String(activeCount)} icon={<CheckCircle className="h-5 w-5 text-white" />} color="bg-blue-500" />
        <StatCard title="On Trial" value={String(trialCount)} icon={<Crown className="h-5 w-5 text-white" />} color="bg-amber-500" />
        <StatCard title="Avg Health" value={`${avgHealth}%`} icon={<Heart className="h-5 w-5 text-white" />} color="bg-violet-500" />
      </div>

      <SectionCard title="Client Overview">
        <div className="mb-4 flex flex-wrap gap-3">
          <div className="flex flex-1 items-center gap-2 rounded-lg bg-slate-100 px-3 py-2">
            <Search className="h-4 w-4 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by business or owner name..." className="flex-1 bg-transparent text-sm outline-none" />
          </div>
          <div className="flex gap-1 rounded-lg bg-slate-200 p-1">
            {(['all', 'active', 'trial', 'suspended'] as const).map(f => (
              <button key={f} onClick={() => setFilter(f)} className={`rounded-md px-3 py-1.5 text-sm font-medium capitalize transition-colors ${filter === f ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500'}`}>{f}</button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-slate-300">
            <Users className="mb-2 h-10 w-10" />
            <p className="text-sm text-slate-400">No clients found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-slate-100 text-left text-xs text-slate-400"><th className="pb-2 font-medium">Business</th><th className="pb-2 font-medium">Owner</th><th className="pb-2 font-medium">Plan</th><th className="pb-2 font-medium">Status</th><th className="pb-2 text-right font-medium">Health</th><th className="pb-2 text-right font-medium">Revenue</th><th className="pb-2 text-right font-medium">Staff</th><th className="pb-2 text-right font-medium">Actions</th></tr></thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map(c => (
                  <tr key={c.id} className="hover:bg-slate-50">
                    <td className="py-3 font-medium text-slate-700">{c.businessName}</td>
                    <td className="py-3 text-slate-600">{c.ownerName}</td>
                    <td className="py-3"><Badge status={c.plan} variant={c.plan === 'Enterprise' ? 'info' : c.plan === 'Business' ? 'success' : 'neutral'} /></td>
                    <td className="py-3"><Badge status={c.status} variant={c.status === 'active' ? 'success' : c.status === 'trial' ? 'warning' : 'danger'} /></td>
                    <td className="py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {c.healthScore >= 80 ? <TrendingUp className="h-3.5 w-3.5 text-emerald-500" /> : <TrendingDown className="h-3.5 w-3.5 text-amber-500" />}
                        <span className={c.healthScore >= 80 ? 'text-emerald-600' : 'text-amber-600'}>{c.healthScore}%</span>
                      </div>
                    </td>
                    <td className="py-3 text-right text-slate-600">{formatKES(c.monthlyRevenue)}</td>
                    <td className="py-3 text-right text-slate-600">{c.staffCount}</td>
                    <td className="py-3 text-right"><div className="flex items-center justify-end gap-1"><button onClick={() => setShowClient(c)} className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-emerald-600"><Eye className="h-4 w-4" /></button><button className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100"><MoreVertical className="h-4 w-4" /></button></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </SectionCard>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <SectionCard title="Plans & Subscriptions">
          <div className="space-y-3">
            {[
              { name: 'Starter', price: 1500, features: '1 till · 100 products · Basic reports', clients: store.adminClients.filter(c => c.plan === 'Starter').length },
              { name: 'Business', price: 4500, features: '5 tills · Unlimited products · Full suite', clients: store.adminClients.filter(c => c.plan === 'Business').length },
              { name: 'Enterprise', price: 12000, features: 'Unlimited tills · Multi-branch · API access', clients: store.adminClients.filter(c => c.plan === 'Enterprise').length },
            ].map(plan => (
              <div key={plan.name} className="flex items-center justify-between rounded-lg border border-slate-100 p-4 hover:border-emerald-200">
                <div><p className="text-sm font-bold text-slate-700">{plan.name} Plan</p><p className="text-xs text-slate-400">{plan.features}</p><p className="mt-1 text-xs text-emerald-600">{plan.clients} client{plan.clients !== 1 ? 's' : ''}</p></div>
                <div className="text-right"><p className="text-lg font-bold text-slate-700">{formatKES(plan.price)}</p><p className="text-xs text-slate-400">per month</p></div>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Complimentary & Trial Access">
          <div className="space-y-3">
            {store.adminClients.filter(c => c.subscriptionStatus !== 'paid' || c.status === 'trial').map(c => (
              <div key={c.id} className="flex items-center justify-between rounded-lg border border-slate-100 p-3">
                <div><p className="text-sm font-medium text-slate-700">{c.businessName}</p><p className="text-xs text-slate-400">{c.ownerName} · {c.plan} · {c.subscriptionStatus}</p></div>
                <div className="flex gap-2">
                  <button onClick={() => store.updateAdminClient(c.id, { subscriptionStatus: 'paid', status: 'active' })} className="rounded-md bg-emerald-100 px-3 py-1.5 text-xs font-medium text-emerald-600 hover:bg-emerald-200">Activate</button>
                  <button onClick={() => store.updateAdminClient(c.id, { subscriptionStatus: 'complimentary' })} className="rounded-md bg-blue-100 px-3 py-1.5 text-xs font-medium text-blue-600 hover:bg-blue-200">Comp</button>
                </div>
              </div>
            ))}
            {store.adminClients.filter(c => c.subscriptionStatus !== 'paid' || c.status === 'trial').length === 0 && <p className="py-4 text-center text-sm text-slate-400">All clients on paid plans</p>}
          </div>
        </SectionCard>
      </div>

      {/* Invite Modal */}
      {showInvite && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowInvite(false)}>
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><Send className="h-5 w-5 text-emerald-500" /><h2 className="text-lg font-bold text-slate-800">Private Owner Invitation</h2></div><button onClick={() => setShowInvite(false)} className="text-slate-400"><X className="h-5 w-5" /></button></div>
            <p className="mb-4 text-sm text-slate-500">Send a private invitation to a new shop owner. They'll receive a setup link to configure their account.</p>
            <div className="space-y-4">
              <div><label className="mb-1 block text-xs font-medium text-slate-500">Owner Name</label><input value={invName} onChange={(e) => setInvName(e.target.value)} placeholder="John Mwangi" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" /></div>
              <div><label className="mb-1 block text-xs font-medium text-slate-500">Business Name</label><input value={invBusiness} onChange={(e) => setInvBusiness(e.target.value)} placeholder="BiziSmart Supermarket" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" /></div>
              <div><label className="mb-1 block text-xs font-medium text-slate-500">Phone Number</label><input type="tel" value={invPhone} onChange={(e) => setInvPhone(e.target.value)} placeholder="0712345678" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" /></div>
              <div><label className="mb-1 block text-xs font-medium text-slate-500">Plan</label><select value={invPlan} onChange={(e) => setInvPlan(e.target.value as AdminClient['plan'])} className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400"><option>Starter</option><option>Business</option><option>Enterprise</option></select></div>
            </div>
            <button onClick={handleInvite} disabled={!invName || !invBusiness || !invPhone} className="mt-5 w-full rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white hover:bg-emerald-600 disabled:opacity-40"><Send className="mr-1 inline h-4 w-4" /> Send Invitation</button>
          </div>
        </div>
      )}

      {/* Client Detail Modal */}
      {showClient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowClient(null)}>
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold text-slate-800">{showClient.businessName}</h2><button onClick={() => setShowClient(null)} className="text-slate-400"><X className="h-5 w-5" /></button></div>
            <div className="mb-4 grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-slate-50 p-3"><p className="text-xs text-slate-400">Owner</p><p className="text-sm font-medium text-slate-700">{showClient.ownerName}</p></div>
              <div className="rounded-lg bg-slate-50 p-3"><p className="text-xs text-slate-400">Phone</p><p className="text-sm font-medium text-slate-700">{showClient.phone}</p></div>
              <div className="rounded-lg bg-slate-50 p-3"><p className="text-xs text-slate-400">Plan</p><p className="text-sm font-medium text-slate-700">{showClient.plan}</p></div>
              <div className="rounded-lg bg-slate-50 p-3"><p className="text-xs text-slate-400">Staff Count</p><p className="text-sm font-medium text-slate-700">{showClient.staffCount}</p></div>
              <div className="rounded-lg bg-slate-50 p-3"><p className="text-xs text-slate-400">Health Score</p><p className="text-sm font-bold text-emerald-600">{showClient.healthScore}%</p></div>
              <div className="rounded-lg bg-slate-50 p-3"><p className="text-xs text-slate-400">Last Active</p><p className="text-sm font-medium text-slate-700">{showClient.lastActive}</p></div>
            </div>
            <div className="mb-4"><p className="mb-2 text-xs font-medium text-slate-400">Assigned Features</p><div className="flex flex-wrap gap-2">{showClient.features.map(f => <Badge key={f} status={f} variant="info" />)}</div></div>
            <div className="flex gap-3">
              <button className="flex-1 rounded-xl border border-slate-200 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50">Staff Lookup</button>
              <button onClick={() => { store.updateAdminClient(showClient.id, { status: showClient.status === 'active' ? 'suspended' : 'active' }); setShowClient(null); }} className="flex-1 rounded-xl bg-amber-500 py-2.5 text-sm font-bold text-white hover:bg-amber-600">{showClient.status === 'active' ? 'Suspend' : 'Activate'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import { useState } from 'react';
import { Landmark, Plus, Upload, Download, CheckCircle, X, RefreshCw, AlertCircle, Building2, FileText } from 'lucide-react';
import { StatCard, SectionCard, Badge } from '@/components/ui/Primitives';
import { formatKES } from '@/store/useStore';
import type { Store as StoreType } from '@/store/useStore';

interface Props { store: StoreType; }

export function Banking({ store }: Props) {
  const [showAdd, setShowAdd] = useState(false);
  const [importAccount, setImportAccount] = useState<string | null>(null);
  const [reconcileNotice, setReconcileNotice] = useState('');

  // add account form
  const [accName, setAccName] = useState('');
  const [accBank, setAccBank] = useState('');
  const [accNumber, setAccNumber] = useState('');

  const totalBalance = store.bankAccounts.reduce((s, a) => s + a.balance, 0);
  const totalUnreconciled = store.bankAccounts.flatMap(a => a.entries).filter(e => !e.reconciled).length;

  const showNotice = (msg: string) => { setReconcileNotice(msg); setTimeout(() => setReconcileNotice(''), 3000); };

  const handleAddAccount = () => {
    if (!accName || !accBank || !accNumber) return;
    store.addBankAccount({ name: accName, bank: accBank, accountNumber: accNumber });
    setAccName(''); setAccBank(''); setAccNumber('');
    setShowAdd(false);
    showNotice('Bank account added successfully');
  };

  const handleImport = () => {
    if (!importAccount) return;
    // simulate imported statement entries
    const sampleEntries = [
      { date: '2026-10-15', description: 'CRDB Mobile Transfer', amount: 45000, type: 'credit' as const },
      { date: '2026-10-14', description: 'Supplier cheque - Bidco', amount: 30000, type: 'debit' as const },
      { date: '2026-10-13', description: 'Cash deposit branch', amount: 80000, type: 'credit' as const },
    ];
    store.importBankStatement(importAccount, sampleEntries);
    showNotice(`Imported ${sampleEntries.length} statement entries`);
    setImportAccount(null);
  };

  return (
    <div className="space-y-5 p-4 lg:p-6">
      {reconcileNotice && <div className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-600">{reconcileNotice}</div>}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Total Bank Balance" value={formatKES(totalBalance)} icon={<Landmark className="h-5 w-5 text-white" />} color="bg-emerald-500" />
        <StatCard title="Accounts" value={String(store.bankAccounts.length)} icon={<Building2 className="h-5 w-5 text-white" />} color="bg-blue-500" />
        <StatCard title="Unreconciled" value={String(totalUnreconciled)} icon={<AlertCircle className="h-5 w-5 text-white" />} color="bg-amber-500" />
        <StatCard title="Reconciled" value={String(store.bankAccounts.flatMap(a => a.entries).filter(e => e.reconciled).length)} icon={<CheckCircle className="h-5 w-5 text-white" />} color="bg-violet-500" />
      </div>

      <div className="flex justify-end gap-2">
        <button onClick={() => setImportAccount(store.bankAccounts[0]?.id ?? '')} className="flex items-center gap-1.5 rounded-lg bg-slate-100 px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200"><Upload className="h-4 w-4" /> Import Statement</button>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 rounded-lg bg-emerald-500 px-3 py-2 text-sm font-bold text-white hover:bg-emerald-600"><Plus className="h-4 w-4" /> Add Account</button>
      </div>

      {/* Import Modal */}
      {importAccount && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setImportAccount(null)}>
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2"><FileText className="h-5 w-5 text-blue-500" /><h2 className="text-lg font-bold text-slate-800">Import Bank Statement</h2></div>
              <button onClick={() => setImportAccount(null)} className="text-slate-400"><X className="h-5 w-5" /></button>
            </div>
            <div className="mb-4">
              <label className="mb-1 block text-xs font-medium text-slate-500">Select Account</label>
              <select value={importAccount} onChange={(e) => setImportAccount(e.target.value)} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400">
                {store.bankAccounts.map(a => <option key={a.id} value={a.id}>{a.name} — {a.bank}</option>)}
              </select>
            </div>
            <div className="mb-4 rounded-lg bg-blue-50 p-3 text-xs text-blue-600">Upload a CSV or PDF statement file. The system will parse entries and match them against transactions for reconciliation.</div>
            <div className="mb-4 flex items-center justify-center rounded-lg border-2 border-dashed border-slate-200 p-8 text-center">
              <div>
                <Upload className="mx-auto mb-2 h-8 w-8 text-slate-300" />
                <p className="text-sm text-slate-500">Drop statement file here or click to browse</p>
                <p className="text-xs text-slate-400">CSV, PDF, or MT940 format</p>
              </div>
            </div>
            <button onClick={handleImport} className="w-full rounded-xl bg-blue-500 py-3 text-sm font-bold text-white hover:bg-blue-600">Import 3 Sample Entries</button>
          </div>
        </div>
      )}

      {/* Add Account Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowAdd(false)}>
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2"><Plus className="h-5 w-5 text-emerald-500" /><h2 className="text-lg font-bold text-slate-800">Add Bank Account</h2></div>
              <button onClick={() => setShowAdd(false)} className="text-slate-400"><X className="h-5 w-5" /></button>
            </div>
            <div className="space-y-4">
              <div><label className="mb-1 block text-xs font-medium text-slate-500">Account Name</label><input value={accName} onChange={(e) => setAccName(e.target.value)} placeholder="e.g. Main Account" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" /></div>
              <div><label className="mb-1 block text-xs font-medium text-slate-500">Bank Name</label><input value={accBank} onChange={(e) => setAccBank(e.target.value)} placeholder="e.g. CRDB Bank" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" /></div>
              <div><label className="mb-1 block text-xs font-medium text-slate-500">Account Number</label><input value={accNumber} onChange={(e) => setAccNumber(e.target.value)} placeholder="e.g. 0151234567001" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" /></div>
            </div>
            <button onClick={handleAddAccount} disabled={!accName || !accBank || !accNumber} className="mt-5 w-full rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white hover:bg-emerald-600 disabled:opacity-40">Add Account</button>
          </div>
        </div>
      )}

      {store.bankAccounts.map(account => (
        <SectionCard key={account.id} title={`${account.name} — ${account.bank}`} action={<Badge status={`Account: ${account.accountNumber.slice(-4).padStart(4, '*')}`} variant="info" />}>
          <div className="mb-4 flex items-center justify-between rounded-lg bg-emerald-50 p-4">
            <div><p className="text-xs text-emerald-600">Current Balance</p><p className="text-2xl font-bold text-emerald-700">{formatKES(account.balance)}</p></div>
            <button className="flex items-center gap-1.5 rounded-lg bg-white px-3 py-2 text-sm font-medium text-emerald-600 hover:bg-emerald-100"><Download className="h-4 w-4" /> Export Statement</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-slate-100 text-left text-xs text-slate-400"><th className="pb-2 font-medium">Date</th><th className="pb-2 font-medium">Description</th><th className="pb-2 text-right font-medium">Credit</th><th className="pb-2 text-right font-medium">Debit</th><th className="pb-2 text-center font-medium">Reconciled</th><th className="pb-2 text-right font-medium">Action</th></tr></thead>
              <tbody className="divide-y divide-slate-50">
                {account.entries.map(entry => (
                  <tr key={entry.id} className="hover:bg-slate-50">
                    <td className="py-2.5 text-slate-600">{entry.date}</td>
                    <td className="py-2.5 text-slate-700">{entry.description}{entry.imported && <span className="ml-2 rounded bg-blue-100 px-1.5 py-0.5 text-[10px] text-blue-600">Imported</span>}</td>
                    <td className="py-2.5 text-right text-emerald-600">{entry.type === 'credit' ? formatKES(entry.amount) : '—'}</td>
                    <td className="py-2.5 text-right text-red-600">{entry.type === 'debit' ? formatKES(entry.amount) : '—'}</td>
                    <td className="py-2.5 text-center">{entry.reconciled ? <CheckCircle className="mx-auto h-4 w-4 text-emerald-500" /> : <div className="mx-auto h-4 w-4 rounded-full border-2 border-amber-300" />}</td>
                    <td className="py-2.5 text-right">{!entry.reconciled && <button onClick={() => { store.reconcileBankEntry(account.id, entry.id); showNotice('Entry reconciled'); }} className="rounded-md bg-emerald-100 px-2 py-1 text-xs font-medium text-emerald-600 hover:bg-emerald-200">Reconcile</button>}</td>
                  </tr>
                ))}
                {account.entries.length === 0 && <tr><td colSpan={6} className="py-8 text-center text-sm text-slate-400">No entries yet. Import a statement to get started.</td></tr>}
              </tbody>
            </table>
          </div>
        </SectionCard>
      ))}
    </div>
  );
}

import { useState } from 'react';
import { MessageSquare, Smartphone, Send, Bell, CheckCircle, XCircle, Clock, AlertTriangle, Zap, Settings as SettingsIcon, X } from 'lucide-react';
import { StatCard, SectionCard, Badge } from '@/components/ui/Primitives';
import { formatKES } from '@/store/useStore';
import type { Store as StoreType } from '@/store/useStore';

interface Props { store: StoreType; }

export function Messaging({ store }: Props) {
  const [showSettings, setShowSettings] = useState(false);
  const [filter, setFilter] = useState<'all' | 'sent' | 'failed' | 'uncertain'>('all');

  const filtered = store.messageLog.filter(m => filter === 'all' || m.status === filter);
  const sentCount = store.messageLog.filter(m => m.status === 'sent').length;
  const failedCount = store.messageLog.filter(m => m.status === 'failed').length;
  const uncertainCount = store.messageLog.filter(m => m.status === 'uncertain').length;

  const statusConfig = {
    sent: { icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Delivered', variant: 'success' as const },
    failed: { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50', label: 'Failed', variant: 'danger' as const },
    pending: { icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Pending', variant: 'warning' as const },
    uncertain: { icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Uncertain', variant: 'warning' as const },
  };

  return (
    <div className="space-y-5 p-4 lg:p-6">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Total Messages" value={String(store.messageLog.length)} icon={<MessageSquare className="h-5 w-5 text-white" />} color="bg-blue-500" />
        <StatCard title="Delivered" value={String(sentCount)} icon={<CheckCircle className="h-5 w-5 text-white" />} color="bg-emerald-500" />
        <StatCard title="Failed" value={String(failedCount)} icon={<XCircle className="h-5 w-5 text-white" />} color="bg-red-500" />
        <StatCard title="Uncertain" value={String(uncertainCount)} icon={<AlertTriangle className="h-5 w-5 text-white" />} color="bg-amber-500" />
      </div>

      <div className="flex justify-end">
        <button onClick={() => setShowSettings(true)} className="flex items-center gap-1.5 rounded-lg bg-slate-100 px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200"><SettingsIcon className="h-4 w-4" /> Notification Settings</button>
      </div>

      <SectionCard title="Delivery History">
        <div className="mb-4 flex gap-2">
          {(['all', 'sent', 'failed', 'uncertain'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`rounded-lg px-3 py-1.5 text-sm font-medium capitalize transition-colors ${filter === f ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>{f}</button>
          ))}
        </div>
        <div className="space-y-2">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-slate-300">
              <MessageSquare className="mb-2 h-10 w-10" />
              <p className="text-sm text-slate-400">No messages found</p>
            </div>
          ) : filtered.map(msg => {
            const cfg = statusConfig[msg.status];
            const StatusIcon = cfg.icon;
            return (
              <div key={msg.id} className="flex items-start gap-3 rounded-lg border border-slate-100 p-3 hover:bg-slate-50">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100">
                  {msg.type === 'whatsapp' ? <MessageSquare className="h-4 w-4 text-green-600" /> : <Smartphone className="h-4 w-4 text-blue-600" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-slate-700">{msg.recipientName}</p>
                    <span className="text-xs text-slate-400">· {msg.recipient}</span>
                    <Badge status={msg.category} variant="neutral" />
                  </div>
                  <p className="mt-0.5 truncate text-xs text-slate-500">{msg.content}</p>
                  <p className="mt-0.5 text-[10px] text-slate-400">{msg.time} · via {msg.type}</p>
                  {msg.providerUnavailable && <p className="mt-1 flex items-center gap-1 text-xs text-red-500"><AlertTriangle className="h-3 w-3" /> Provider unavailable — message queued for retry</p>}
                </div>
                <div className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 ${cfg.bg}`}>
                  <StatusIcon className={`h-3.5 w-3.5 ${cfg.color}`} />
                  <span className={`text-xs font-medium ${cfg.color}`}>{cfg.label}</span>
                </div>
              </div>
            );
          })}
        </div>
      </SectionCard>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <SectionCard title="Automation Controls">
          <div className="space-y-3">
            {[
              { key: 'receipts', label: 'Auto-send receipts via WhatsApp', desc: 'Send receipt after every completed sale' },
              { key: 'debtReminders', label: 'Debt reminders', desc: 'Weekly SMS to customers with outstanding debt' },
              { key: 'promotions', label: 'Promotion broadcasts', desc: 'Send active promotions to opted-in customers' },
              { key: 'lowStockAlerts', label: 'Low stock alerts', desc: 'Notify manager when products hit reorder level' },
            ].map(item => (
              <div key={item.key} className="flex items-center justify-between rounded-lg border border-slate-100 p-3">
                <div className="flex items-center gap-3"><Bell className="h-5 w-5 text-slate-400" /><div><p className="text-sm font-medium text-slate-700">{item.label}</p><p className="text-xs text-slate-400">{item.desc}</p></div></div>
                <button onClick={() => store.updateNotificationSettings({ [item.key]: !store.notificationSettings[item.key as keyof typeof store.notificationSettings] })} className={`relative h-6 w-11 rounded-full transition-colors ${store.notificationSettings[item.key as keyof typeof store.notificationSettings] ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                  <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${store.notificationSettings[item.key as keyof typeof store.notificationSettings] ? 'left-[22px]' : 'left-0.5'}`} />
                </button>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Provider Status">
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border border-slate-100 p-3">
              <div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-lg bg-green-100"><MessageSquare className="h-4 w-4 text-green-600" /></div><div><p className="text-sm font-medium text-slate-700">WhatsApp Business API</p><p className="text-xs text-slate-400">Via Meta Business Platform</p></div></div>
              <Badge status="Connected" variant="success" />
            </div>
            <div className="flex items-center justify-between rounded-lg border border-slate-100 p-3">
              <div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-100"><Smartphone className="h-4 w-4 text-blue-600" /></div><div><p className="text-sm font-medium text-slate-700">SMS Gateway</p><p className="text-xs text-slate-400">Africa's Talking</p></div></div>
              <Badge status="Connected" variant="success" />
            </div>
            <div className="flex items-center justify-between rounded-lg border border-amber-200 bg-amber-50 p-3">
              <div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-100"><Zap className="h-4 w-4 text-amber-600" /></div><div><p className="text-sm font-medium text-slate-700">Selcom Mobile Payments</p><p className="text-xs text-amber-600">TRA/Deferred — disabled</p></div></div>
              <Badge status="Disabled" variant="neutral" />
            </div>
          </div>
        </SectionCard>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowSettings(false)}>
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><Bell className="h-5 w-5 text-emerald-500" /><h2 className="text-lg font-bold text-slate-800">Notification Settings</h2></div><button onClick={() => setShowSettings(false)} className="text-slate-400"><X className="h-5 w-5" /></button></div>
            <div className="space-y-4">
              <div><label className="mb-1 block text-xs font-medium text-slate-500">Customer Consent</label><div className="rounded-lg bg-blue-50 p-3 text-xs text-blue-600">Customers must opt-in to receive WhatsApp/SMS. Consent is captured at registration and can be toggled per customer.</div></div>
              {Object.entries(store.notificationSettings).map(([key, val]) => (
                <div key={key} className="flex items-center justify-between rounded-lg border border-slate-100 p-3">
                  <span className="text-sm font-medium capitalize text-slate-700">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                  <button onClick={() => store.updateNotificationSettings({ [key]: !val })} className={`relative h-6 w-11 rounded-full transition-colors ${val ? 'bg-emerald-500' : 'bg-slate-300'}`}><span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${val ? 'left-[22px]' : 'left-0.5'}`} /></button>
                </div>
              ))}
            </div>
            <button onClick={() => setShowSettings(false)} className="mt-5 w-full rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white hover:bg-emerald-600">Save Settings</button>
          </div>
        </div>
      )}
    </div>
  );
}

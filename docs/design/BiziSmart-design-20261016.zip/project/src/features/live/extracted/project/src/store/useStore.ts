import { useState, useCallback, useMemo } from 'react';
import type {
  Product, CartItem, Customer, Supplier, PurchaseOrder, PurchaseOrderItem,
  Staff, Till, Transaction, Approval, StockMovement, PriceChange, Promotion,
  AuditEntry, MpesaPayment, HeldSale, StockTake, Screen, Role, Permission,
  BankAccount, BankEntry, Expense, MessageLog, NotificationSetting,
  OfflineOperation, SuspiciousActivity, LossThreshold, CommissionSetting,
  Incentive, AdminClient, Device, ImportExportRow, Language,
} from '@/types';
import { ROLE_PERMISSIONS, translations } from '@/types';

// --- seed data ---
const colors = ['bg-rose-500','bg-blue-500','bg-emerald-500','bg-amber-500','bg-cyan-500','bg-violet-500','bg-orange-500','bg-teal-500','bg-pink-500','bg-indigo-500','bg-lime-500','bg-sky-500'];

const seedProducts: Product[] = [
  { id:'p1',name:'Sifted Maize Flour 2kg',barcode:'6001234500011',category:'Cereals',department:'Grocery',price:185,cost:165,unit:'each',stock:240,reorderLevel:50,taxable:true,imageColor:colors[0],packSize:10,packPrice:1750,cartonSize:20,cartonPrice:3300 },
  { id:'p2',name:'Sugar 1kg',barcode:'6001234500028',category:'Baking',department:'Grocery',price:175,cost:158,unit:'each',stock:180,reorderLevel:60,taxable:true,imageColor:colors[1],packSize:12,packPrice:1980,cartonSize:24,cartonPrice:3900 },
  { id:'p3',name:'Cooking Oil 1L',barcode:'6001234500035',category:'Cooking',department:'Grocery',price:320,cost:290,unit:'each',stock:95,reorderLevel:40,taxable:true,imageColor:colors[2],packSize:12,packPrice:3600,cartonSize:24,cartonPrice:6900 },
  { id:'p4',name:'Long Grain Rice 2kg',barcode:'6001234500042',category:'Cereals',department:'Grocery',price:340,cost:300,unit:'each',stock:120,reorderLevel:45,taxable:true,imageColor:colors[3] },
  { id:'p5',name:'Wheat Flour 1kg',barcode:'6001234500059',category:'Baking',department:'Grocery',price:145,cost:128,unit:'each',stock:85,reorderLevel:40,taxable:true,imageColor:colors[4] },
  { id:'p6',name:'Tea Leaves 500g',barcode:'6001234500066',category:'Beverages',department:'Grocery',price:210,cost:185,unit:'each',stock:160,reorderLevel:50,taxable:true,imageColor:colors[5] },
  { id:'p7',name:'Fresh Milk 500ml',barcode:'6001234500073',category:'Dairy',department:'Dairy',price:65,cost:55,unit:'each',stock:48,reorderLevel:30,expiry:'2026-10-14',batch:'MILK-102',taxable:false,imageColor:colors[6] },
  { id:'p8',name:'Bread Loaf 400g',barcode:'6001234500080',category:'Bakery',department:'Bakery',price:55,cost:45,unit:'each',stock:32,reorderLevel:20,expiry:'2026-10-10',batch:'BRD-088',taxable:false,imageColor:colors[7] },
  { id:'p9',name:'Eggs Tray (30)',barcode:'6001234500097',category:'Dairy',department:'Dairy',price:420,cost:380,unit:'pack',stock:25,reorderLevel:15,taxable:false,imageColor:colors[8] },
  { id:'p10',name:'Tomatoes 1kg',barcode:'2000000000017',category:'Vegetables',department:'Produce',price:120,cost:90,unit:'kg',stock:60,reorderLevel:20,taxable:false,imageColor:colors[9],weighed:true,scaleBarcode:'20' },
  { id:'p11',name:'Onions 1kg',barcode:'2000000000024',category:'Vegetables',department:'Produce',price:100,cost:75,unit:'kg',stock:45,reorderLevel:20,taxable:false,imageColor:colors[10],weighed:true,scaleBarcode:'20' },
  { id:'p12',name:'Potatoes 1kg',barcode:'2000000000031',category:'Vegetables',department:'Produce',price:80,cost:55,unit:'kg',stock:70,reorderLevel:25,taxable:false,imageColor:colors[11],weighed:true,scaleBarcode:'20' },
  { id:'p13',name:'Bananas 1kg',barcode:'2000000000048',category:'Fruits',department:'Produce',price:110,cost:85,unit:'kg',stock:38,reorderLevel:15,taxable:false,imageColor:colors[0],weighed:true,scaleBarcode:'20' },
  { id:'p14',name:'Mangoes 1kg',barcode:'2000000000055',category:'Fruits',department:'Produce',price:150,cost:115,unit:'kg',stock:22,reorderLevel:15,taxable:false,imageColor:colors[1],weighed:true,scaleBarcode:'20' },
  { id:'p15',name:'Coca Cola 500ml',barcode:'5449000000996',category:'Sodas',department:'Beverages',price:70,cost:55,unit:'each',stock:200,reorderLevel:60,taxable:true,imageColor:colors[2],packSize:12,packPrice:780,cartonSize:24,cartonPrice:1500 },
  { id:'p16',name:'Bottled Water 500ml',barcode:'5449000001009',category:'Water',department:'Beverages',price:30,cost:20,unit:'each',stock:300,reorderLevel:80,taxable:true,imageColor:colors[3] },
  { id:'p17',name:'Bar Soap 800g',barcode:'6001234500103',category:'Cleaning',department:'Household',price:180,cost:155,unit:'each',stock:90,reorderLevel:30,taxable:true,imageColor:colors[4] },
  { id:'p18',name:'Detergent 2kg',barcode:'6001234500110',category:'Cleaning',department:'Household',price:350,cost:300,unit:'each',stock:55,reorderLevel:25,taxable:true,imageColor:colors[5] },
  { id:'p19',name:'Salt 500g',barcode:'6001234500127',category:'Baking',department:'Grocery',price:45,cost:35,unit:'each',stock:140,reorderLevel:40,taxable:true,imageColor:colors[6] },
  { id:'p20',name:'Pasta 500g',barcode:'8076809513758',category:'Cereals',department:'Grocery',price:95,cost:78,unit:'each',stock:110,reorderLevel:35,taxable:true,imageColor:colors[7] },
  { id:'p21',name:'Peanut Butter 350g',barcode:'6001234500134',category:'Spreads',department:'Grocery',price:280,cost:240,unit:'each',stock:42,reorderLevel:20,taxable:true,imageColor:colors[8] },
  { id:'p22',name:'Tomato Sauce 500g',barcode:'6001234500141',category:'Sauces',department:'Grocery',price:165,cost:140,unit:'each',stock:68,reorderLevel:25,taxable:true,imageColor:colors[9] },
  { id:'p23',name:'Biscuits Pack',barcode:'6001234500158',category:'Snacks',department:'Bakery',price:60,cost:48,unit:'pack',stock:130,reorderLevel:40,expiry:'2026-12-01',batch:'BSC-205',taxable:true,imageColor:colors[10] },
  { id:'p24',name:'Toothpaste 100g',barcode:'6001234500165',category:'Personal Care',department:'Household',price:190,cost:165,unit:'each',stock:75,reorderLevel:25,taxable:true,imageColor:colors[11] },
  { id:'p25',name:'Toilet Paper 4-roll',barcode:'6001234500172',category:'Cleaning',department:'Household',price:220,cost:190,unit:'pack',stock:85,reorderLevel:30,taxable:true,imageColor:colors[0] },
  { id:'p26',name:'Matchbox Pack',barcode:'6001234500189',category:'Household',department:'Household',price:25,cost:18,unit:'pack',stock:200,reorderLevel:50,taxable:true,imageColor:colors[1] },
  { id:'p27',name:'Sardines Tin 155g',barcode:'6001234500196',category:'Canned',department:'Grocery',price:85,cost:70,unit:'each',stock:95,reorderLevel:30,expiry:'2027-06-01',batch:'SRD-310',taxable:true,imageColor:colors[2] },
  { id:'p28',name:'Baked Beans 400g',barcode:'6001234500202',category:'Canned',department:'Grocery',price:120,cost:100,unit:'each',stock:60,reorderLevel:25,expiry:'2027-03-01',batch:'BNZ-118',taxable:true,imageColor:colors[3] },
  { id:'p29',name:'Spices Mix 50g',barcode:'6001234500219',category:'Spices',department:'Grocery',price:75,cost:58,unit:'each',stock:48,reorderLevel:20,taxable:true,imageColor:colors[4] },
  { id:'p30',name:'Honey 250g',barcode:'6001234500226',category:'Spreads',department:'Grocery',price:350,cost:300,unit:'each',stock:28,reorderLevel:15,taxable:true,imageColor:colors[5] },
  { id:'p31',name:'Groundnuts 500g',barcode:'6001234500233',category:'Snacks',department:'Grocery',price:200,cost:170,unit:'pack',stock:52,reorderLevel:20,taxable:true,imageColor:colors[6] },
  { id:'p32',name:'Orange Juice 1L',barcode:'6001234500240',category:'Juices',department:'Beverages',price:180,cost:150,unit:'each',stock:65,reorderLevel:25,expiry:'2026-10-20',batch:'OJ-045',taxable:true,imageColor:colors[7] },
  { id:'p33',name:'Yoghurt 500ml',barcode:'6001234500257',category:'Dairy',department:'Dairy',price:120,cost:100,unit:'each',stock:40,reorderLevel:20,expiry:'2026-10-12',batch:'YOG-077',taxable:false,imageColor:colors[8] },
  { id:'p34',name:'Cheese 200g',barcode:'6001234500264',category:'Dairy',department:'Dairy',price:380,cost:330,unit:'each',stock:18,reorderLevel:10,expiry:'2026-11-01',batch:'CHS-012',taxable:false,imageColor:colors[9] },
  { id:'p35',name:'Sausages 500g',barcode:'6001234500271',category:'Meat',department:'Butchery',price:350,cost:300,unit:'pack',stock:30,reorderLevel:15,expiry:'2026-10-11',batch:'SAU-066',taxable:false,imageColor:colors[10] },
  { id:'p36',name:'Chicken Whole 1kg',barcode:'2000000000062',category:'Meat',department:'Butchery',price:480,cost:420,unit:'kg',stock:25,reorderLevel:10,taxable:false,imageColor:colors[11],weighed:true,scaleBarcode:'20' },
];

const seedCustomers: Customer[] = [
  { id:'c1',name:'Wanjiru Kamau',phone:'0712345678',email:'wanjiru@gmail.com',creditLimit:5000,debt:1200,totalSpent:28500,joinedDate:'2025-03-15',loyaltyPoints:285,loyaltyConsent:true,whatsappConsent:true },
  { id:'c2',name:'Otieno Ochieng',phone:'0723456789',creditLimit:10000,debt:0,totalSpent:52000,joinedDate:'2024-11-20',loyaltyPoints:520,loyaltyConsent:true,whatsappConsent:false },
  { id:'c3',name:'Amina Hassan',phone:'0734567890',creditLimit:3000,debt:2800,totalSpent:15800,joinedDate:'2025-06-01',loyaltyPoints:158,loyaltyConsent:false,whatsappConsent:false },
  { id:'c4',name:'Mutua Mutua',phone:'0745678901',creditLimit:8000,debt:500,totalSpent:41200,joinedDate:'2025-01-10',loyaltyPoints:412,loyaltyConsent:true,whatsappConsent:true },
  { id:'c5',name:'Faith Cherono',phone:'0756789012',creditLimit:2000,debt:0,totalSpent:9800,joinedDate:'2025-08-05',loyaltyPoints:98,loyaltyConsent:true,whatsappConsent:false },
  { id:'c6',name:'Brian Kiplagat',phone:'0767890123',creditLimit:15000,debt:3500,totalSpent:67500,joinedDate:'2024-08-12',loyaltyPoints:675,loyaltyConsent:true,whatsappConsent:true },
  { id:'c7',name:'Grace Auma',phone:'0778901234',creditLimit:5000,debt:0,totalSpent:22300,joinedDate:'2025-04-22',loyaltyPoints:223,loyaltyConsent:false,whatsappConsent:false },
  { id:'c8',name:'Samuel Mwangi',phone:'0789012345',creditLimit:10000,debt:1800,totalSpent:38900,joinedDate:'2025-02-18',loyaltyPoints:389,loyaltyConsent:true,whatsappConsent:true },
];

const seedSuppliers: Supplier[] = [
  { id:'s1',name:'Bidco Africa Ltd',contact:'James Mwangi',phone:'0722001100',email:'sales@bidco.africa',balance:45000,lastOrder:'2026-09-28',products:12,priceHistory:[{productId:'p3',date:'2026-09-15',price:285},{productId:'p3',date:'2026-09-28',price:290}] },
  { id:'s2',name:'Unilever Kenya',contact:'Sarah Njoki',phone:'0733002200',email:'orders@unilever.co.ke',balance:0,lastOrder:'2026-09-25',products:8,priceHistory:[] },
  { id:'s3',name:'Eastleigh Wholesalers',contact:'Abdi Noor',phone:'0744003300',email:'eastleigh@gmail.com',balance:12500,lastOrder:'2026-10-02',products:25,priceHistory:[{productId:'p2',date:'2026-09-20',price:155},{productId:'p2',date:'2026-10-02',price:158}] },
  { id:'s4',name:'Nairobi Drinks Ltd',contact:'Peter Otieno',phone:'0755004400',email:'info@nairobidrinks.co.ke',balance:8200,lastOrder:'2026-09-30',products:15,priceHistory:[] },
  { id:'s5',name:'Fresh Farm Produce',contact:'Mary Wambui',phone:'0766005500',email:'fresh@farm.co.ke',balance:0,lastOrder:'2026-10-05',products:18,priceHistory:[] },
  { id:'s6',name:'Tuskys Distributors',contact:'David Kiprop',phone:'0777006600',email:'dist@tuskys.co.ke',balance:23000,lastOrder:'2026-09-20',products:30,priceHistory:[] },
];

const seedStaff: Staff[] = [
  { id:'st1',name:'John Mwangi',role:'Owner',phone:'0711001100',pin:'1234',active:true,salesToday:0,attendance:'present',twoFactor:true,clockInTime:'08:00' },
  { id:'st2',name:'Lucy Wambui',role:'Manager',phone:'0711002200',pin:'2345',active:true,salesToday:0,attendance:'present',twoFactor:true,clockInTime:'08:00' },
  { id:'st3',name:'Peter Kamau',role:'Supervisor',phone:'0711003300',pin:'3456',active:true,salesToday:0,attendance:'present',twoFactor:false,clockInTime:'08:00' },
  { id:'st4',name:'Mary Atieno',role:'Cashier',phone:'0711004400',pin:'4567',active:true,salesToday:18500,attendance:'present',twoFactor:false,clockInTime:'08:00' },
  { id:'st5',name:'James Omondi',role:'Cashier',phone:'0711005500',pin:'5678',active:true,salesToday:12300,attendance:'present',twoFactor:false,clockInTime:'08:00' },
  { id:'st6',name:'Faith Njeri',role:'Cashier',phone:'0711006600',pin:'6789',active:true,salesToday:22000,attendance:'present',twoFactor:false,clockInTime:'08:00' },
  { id:'st7',name:'Brian Kiptoo',role:'Cashier',phone:'0711007700',pin:'7890',active:false,salesToday:0,attendance:'absent',twoFactor:false },
  { id:'st8',name:'Sarah Wanjiru',role:'Cashier',phone:'0711008800',pin:'8901',active:true,salesToday:9500,attendance:'present',twoFactor:false,clockInTime:'08:00' },
];

const seedTills: Till[] = [
  { id:'t1',name:'Till 1',cashierId:'st4',cashier:'Mary Atieno',status:'open',openingFloat:5000,closingFloat:null,cashSales:8500,mpesaSales:10000,creditSales:0,transactions:34,voids:1,variance:0,cashDrops:[],paidOuts:[],openedAt:'08:00' },
  { id:'t2',name:'Till 2',cashierId:'st5',cashier:'James Omondi',status:'open',openingFloat:5000,closingFloat:null,cashSales:5300,mpesaSales:7000,creditSales:0,transactions:22,voids:0,variance:0,cashDrops:[],paidOuts:[],openedAt:'08:00' },
  { id:'t3',name:'Till 3',cashierId:'st6',cashier:'Faith Njeri',status:'open',openingFloat:5000,closingFloat:null,cashSales:12000,mpesaSales:10000,creditSales:1850,transactions:45,voids:2,variance:-150,cashDrops:[],paidOuts:[],openedAt:'08:00' },
  { id:'t4',name:'Till 4',cashierId:'st8',cashier:'Sarah Wanjiru',status:'open',openingFloat:5000,closingFloat:null,cashSales:4500,mpesaSales:5000,creditSales:0,transactions:18,voids:0,variance:0,cashDrops:[],paidOuts:[],openedAt:'08:00' },
  { id:'t5',name:'Till 5',cashierId:null,cashier:'—',status:'closed',openingFloat:0,closingFloat:null,cashSales:0,mpesaSales:0,creditSales:0,transactions:0,voids:0,variance:0,cashDrops:[],paidOuts:[],openedAt:null },
];

const now = () => new Date().toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',hour12:true});
const today = () => new Date().toISOString().split('T')[0];
let receiptCounter = 1246;

const seedTxns: Transaction[] = [
  { id:'tx1',receiptNo:'RCP-001234',time:'10:42 AM',date:'2026-10-08',cashierId:'st4',cashier:'Mary Atieno',tillId:'t1',tillName:'Till 1',items:[],total:1250,subtotal:1078,tax:172,discount:0,method:'mpesa',mpesaAmount:1250,mpesaRef:'QGH8X9P2',customer:'Wanjiru Kamau',customerId:'c1',status:'completed',cost:950 },
  { id:'tx2',receiptNo:'RCP-001235',time:'10:38 AM',date:'2026-10-08',cashierId:'st5',cashier:'James Omondi',tillId:'t2',tillName:'Till 2',items:[],total:680,subtotal:586,tax:94,discount:0,method:'cash',cashAmount:680,status:'completed',cost:510 },
  { id:'tx3',receiptNo:'RCP-001236',time:'10:35 AM',date:'2026-10-08',cashierId:'st6',cashier:'Faith Njeri',tillId:'t3',tillName:'Till 3',items:[],total:3200,subtotal:2759,tax:441,discount:0,method:'split',cashAmount:1200,mpesaAmount:2000,customer:'Otieno Ochieng',customerId:'c2',status:'completed',cost:2450 },
  { id:'tx4',receiptNo:'RCP-001237',time:'10:28 AM',date:'2026-10-08',cashierId:'st4',cashier:'Mary Atieno',tillId:'t1',tillName:'Till 1',items:[],total:0,subtotal:0,tax:0,discount:0,method:'cash',status:'voided',cost:0 },
  { id:'tx5',receiptNo:'RCP-001238',time:'10:22 AM',date:'2026-10-08',cashierId:'st8',cashier:'Sarah Wanjiru',tillId:'t4',tillName:'Till 4',items:[],total:450,subtotal:388,tax:62,discount:0,method:'cash',cashAmount:450,status:'completed',cost:340 },
  { id:'tx6',receiptNo:'RCP-001239',time:'10:15 AM',date:'2026-10-08',cashierId:'st6',cashier:'Faith Njeri',tillId:'t3',tillName:'Till 3',items:[],total:1850,subtotal:1850,tax:0,discount:0,method:'credit',customer:'Amina Hassan',customerId:'c3',status:'completed',cost:1520 },
  { id:'tx11',receiptNo:'RCP-001244',time:'09:22 AM',date:'2026-10-08',cashierId:'st4',cashier:'Mary Atieno',tillId:'t1',tillName:'Till 1',items:[],total:980,subtotal:845,tax:135,discount:0,method:'cash',cashAmount:980,customer:'Mutua Mutua',customerId:'c4',status:'refunded',refundAmount:980,cost:720 },
];

const seedAudit: AuditEntry[] = [
  { id:'al1',action:'Approved refund RCP-001244',user:'Peter Kamau',time:'10:15 AM',type:'approval' },
  { id:'al2',action:'Voided transaction RCP-001237',user:'Peter Kamau',time:'10:28 AM',type:'void' },
  { id:'al3',action:'Applied 15% discount on order',user:'Peter Kamau',time:'09:45 AM',type:'discount' },
  { id:'al4',action:'Stock adjustment: Bread Loaf (-2)',user:'Lucy Wambui',time:'08:30 AM',type:'adjustment' },
  { id:'al5',action:'Opened Till 3 with float KSh 5,000',user:'Faith Njeri',time:'07:30 AM',type:'till' },
];

const seedMovements: StockMovement[] = [
  { id:'m1',productId:'p2',productName:'Sugar 1kg',type:'Sale',qty:-5,user:'Mary Atieno',time:'10:42 AM',reason:'',approved:true },
  { id:'m2',productId:'p3',productName:'Cooking Oil 1L',type:'Received',qty:48,user:'Lucy Wambui',time:'09:15 AM',reason:'PO-001 delivery',approved:true },
  { id:'m3',productId:'p7',productName:'Fresh Milk 500ml',type:'Wastage',qty:-3,user:'Peter Kamau',time:'08:50 AM',reason:'Expired stock',approved:true },
  { id:'m4',productId:'p8',productName:'Bread Loaf 400g',type:'Damage',qty:-2,user:'Mary Atieno',time:'08:30 AM',reason:'Crushed during delivery',approved:true },
  { id:'m5',productId:'p6',productName:'Tea Leaves 500g',type:'Adjustment',qty:12,user:'Lucy Wambui',time:'08:00 AM',reason:'Stock take correction',approved:true },
];

const seedApprovals: Approval[] = [
  { id:'ap1',type:'refund',description:'Refund RCP-001244 · 5 items',amount:980,requestedBy:'Mary Atieno',requestedAt:'10:10 AM',status:'pending',transactionId:'tx11' },
];

const seedPromotions: Promotion[] = [
  { id:'promo1',name:'Weekend Sodas 10% Off',type:'percentage',value:10,category:'Sodas',active:true,startDate:'2026-10-07',endDate:'2026-10-09' },
  { id:'promo2',name:'Buy 2 Bread Get 1 Free',type:'bxgy',value:0,buyQty:2,getQty:1,productId:'p8',active:true,startDate:'2026-10-08',endDate:'2026-10-10' },
  { id:'promo3',name:'Bulk Rice 5+ 5% Off',type:'bulk',value:5,buyQty:5,productId:'p4',active:true,startDate:'2026-10-01',endDate:'2026-10-31' },
];

const seedPriceChanges: PriceChange[] = [
  { id:'pc1',productId:'p3',productName:'Cooking Oil 1L',oldPrice:310,newPrice:320,date:'2026-10-01',user:'Lucy Wambui',applied:true },
  { id:'pc2',productId:'p2',productName:'Sugar 1kg',oldPrice:170,newPrice:175,date:'2026-10-03',user:'Lucy Wambui',applied:true },
];

const seedMpesa: MpesaPayment[] = [
  { id:'mp1',phone:'0712345678',amount:1250,ref:'QGH8X9P2',time:'10:42 AM',matched:true,transactionId:'tx1' },
  { id:'mp2',phone:'0722001100',amount:500,ref:'SDK4M1N8',time:'10:50 AM',matched:false },
];

const seedStockTake: StockTake = {
  id:'st-1',department:'Grocery',countedBy:'Lucy Wambui',startedAt:'Oct 8, 08:00 AM',status:'in_progress',
  items: seedProducts.filter(p=>p.department==='Grocery').slice(0,8).map(p=>({productId:p.id,productName:p.name,systemQty:p.stock,countedQty:null,variance:0})),
};

// --- store hook ---
export function useStore() {
  const [currentUser, setCurrentUser] = useState<Staff | null>(null);
  const [screen, setScreen] = useState<Screen>('dashboard');
  const [products, setProducts] = useState<Product[]>(seedProducts);
  const [customers, setCustomers] = useState<Customer[]>(seedCustomers);
  const [suppliers, setSuppliers] = useState<Supplier[]>(seedSuppliers);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([
    { id:'PO-001',supplierId:'s1',supplierName:'Bidco Africa Ltd',date:'2026-10-01',expected:'2026-10-05',status:'received',total:89000,items:[{productId:'p3',name:'Cooking Oil 1L',qty:48,cost:290,total:13920}],paymentTerms:'30 Days',paymentStatus:'partial' },
    { id:'PO-002',supplierId:'s3',supplierName:'Eastleigh Wholesalers',date:'2026-10-03',expected:'2026-10-07',status:'sent',total:45000,items:[{productId:'p2',name:'Sugar 1kg',qty:100,cost:158,total:15800}],paymentTerms:'7 Days',paymentStatus:'unpaid' },
    { id:'PO-003',supplierId:'s5',supplierName:'Fresh Farm Produce',date:'2026-10-05',expected:'2026-10-06',status:'received',total:18000,items:[],paymentTerms:'COD',paymentStatus:'paid' },
    { id:'PO-004',supplierId:'s4',supplierName:'Nairobi Drinks Ltd',date:'2026-10-06',expected:'2026-10-09',status:'partial',total:32000,items:[],paymentTerms:'7 Days',paymentStatus:'unpaid' },
    { id:'PO-005',supplierId:'s2',supplierName:'Unilever Kenya',date:'2026-10-07',expected:'2026-10-11',status:'draft',total:25000,items:[],paymentTerms:'30 Days',paymentStatus:'unpaid' },
  ]);
  const [staffList, setStaffList] = useState<Staff[]>(seedStaff);
  const [tills, setTills] = useState<Till[]>(seedTills);
  const [transactions, setTransactions] = useState<Transaction[]>(seedTxns);
  const [approvals, setApprovals] = useState<Approval[]>(seedApprovals);
  const [stockMovements, setStockMovements] = useState<StockMovement[]>(seedMovements);
  const [priceChanges, setPriceChanges] = useState<PriceChange[]>(seedPriceChanges);
  const [promotions, setPromotions] = useState<Promotion[]>(seedPromotions);
  const [auditLog, setAuditLog] = useState<AuditEntry[]>(seedAudit);
  const [mpesaPayments, setMpesaPayments] = useState<MpesaPayment[]>(seedMpesa);
  const [heldSales, setHeldSales] = useState<HeldSale[]>([]);
  const [stockTake, setStockTake] = useState<StockTake>(seedStockTake);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [activeTillId, setActiveTillId] = useState<string>('t1');

  // --- new state for expanded features ---
  const [language, setLanguage] = useState<Language>('en');
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([
    { id:'b1', name:'Main Account', bank:'CRDB Bank', accountNumber:'0151234567001', balance:1250000, entries:[
      { id:'be1', date:'2026-10-14', description:'M-Pesa settlement', amount:85000, type:'credit', reconciled:true },
      { id:'be2', date:'2026-10-13', description:'Supplier payment - Bidco', amount:45000, type:'debit', reconciled:true },
      { id:'be3', date:'2026-10-15', description:'Cash deposit', amount:120000, type:'credit', reconciled:false, imported:true },
    ]},
  ]);
  const [expenses, setExpenses] = useState<Expense[]>([
    { id:'e1', category:'Transport', description:'Delivery fuel', amount:15000, date:'2026-10-15', user:'Lucy Wambui', status:'approved' },
    { id:'e2', category:'Supplies', description:'Cleaning materials', amount:8500, date:'2026-10-14', user:'Mary Atieno', status:'pending' },
  ]);
  const [messageLog, setMessageLog] = useState<MessageLog[]>([
    { id:'ml1', type:'whatsapp', recipient:'0712345678', recipientName:'Wanjiru Kamau', content:'Receipt RCP-001234', time:'10:42 AM', status:'sent', category:'receipt' },
    { id:'ml2', type:'sms', recipient:'0723456789', recipientName:'Otieno Ochieng', content:'Debt reminder: TSh 0', time:'09:00 AM', status:'failed', category:'reminder' },
  ]);
  const [notificationSettings, setNotificationSettings] = useState<NotificationSetting>({
    receipts: true, promotions: true, debtReminders: true, statements: false, lowStockAlerts: true,
  });
  const [offlineOps, setOfflineOps] = useState<OfflineOperation[]>([]);
  const [onlineStatus, setOnlineStatus] = useState<'online' | 'offline' | 'syncing'>('online');
  const [suspiciousActivity, setSuspiciousActivity] = useState<SuspiciousActivity[]>([
    { id:'sa1', type:'void_spike', description:'3 voids in 1 hour on Till 3', user:'Faith Njeri', time:'10:30 AM', severity:'medium', resolved:false },
    { id:'sa2', type:'cash_variance', description:'Cash variance TSh 150 on Till 3', user:'Faith Njeri', time:'10:00 AM', severity:'low', resolved:false },
  ]);
  const [lossThresholds, setLossThresholds] = useState<LossThreshold>({
    voidLimit: 3, refundLimit: 50000, discountLimit: 15, varianceLimit: 1000, afterHoursStart: '20:00',
  });
  const [commissions, setCommissions] = useState<CommissionSetting[]>([
    { staffId:'st4', staffName:'Mary Atieno', rate: 2, target: 50000, earned: 370 },
    { staffId:'st5', staffName:'James Omondi', rate: 2, target: 50000, earned: 246 },
    { staffId:'st6', staffName:'Faith Njeri', rate: 2.5, target: 50000, earned: 550 },
  ]);
  const [incentives, setIncentives] = useState<Incentive[]>([
    { id:'inc1', name:'Weekend Sales Challenge', description:'Top seller gets TSh 10,000 bonus', type:'sales_target', target: 100000, reward: 10000, active: true, leaderboard:[
      { staffId:'st6', staffName:'Faith Njeri', progress: 78, rank: 1 },
      { staffId:'st4', staffName:'Mary Atieno', progress: 52, rank: 2 },
      { staffId:'st5', staffName:'James Omondi', progress: 38, rank: 3 },
    ]},
  ]);
  const [adminClients, setAdminClients] = useState<AdminClient[]>([
    { id:'ac1', businessName:'BiziSmart Supermarket', ownerName:'John Mwangi', phone:'0711001100', plan:'Business', status:'active', features:['pos','inventory','suppliers','customers','reports','banking'], healthScore: 92, lastActive:'5 min ago', staffCount: 8, monthlyRevenue: 4500, subscriptionStatus:'paid', createdAt:'2024-08-12' },
    { id:'ac2', businessName:'Duka La Bidhaa', ownerName:'Amina Hassan', phone:'0734567890', plan:'Starter', status:'trial', features:['pos','inventory'], healthScore: 65, lastActive:'2 days ago', staffCount: 3, monthlyRevenue: 0, subscriptionStatus:'complimentary', createdAt:'2025-09-01' },
    { id:'ac3', businessName:'MegaMart Arusha', ownerName:'Peter Kimathi', phone:'0722001100', plan:'Enterprise', status:'active', features:['pos','inventory','suppliers','customers','reports','banking','messaging','offline'], healthScore: 88, lastActive:'1 hour ago', staffCount: 25, monthlyRevenue: 12000, subscriptionStatus:'paid', createdAt:'2024-03-15' },
  ]);
  const [devices, setDevices] = useState<Device[]>([
    { id:'d1', name:'Front Counter Tablet', device:'iPad Pro 11"', lastActive:'Active now', status:'Active', approved:true },
    { id:'d2', name:'Till 2 Desktop', device:'HP All-in-One', lastActive:'10 min ago', status:'Active', approved:true },
    { id:'d3', name:'Warehouse Scanner', device:'Zebra TC52', lastActive:'Yesterday', status:'Offline', approved:true },
    { id:'d4', name:'Unknown Device', device:'Samsung Galaxy A14', lastActive:'5 min ago', status:'Pending', approved:false },
  ]);
  const [importPreview, setImportPreview] = useState<ImportExportRow[]>([]);
  const [setupComplete, setSetupComplete] = useState(false);
  const [authenticatorEnrolled, setAuthenticatorEnrolled] = useState(false);
  const [sessionExpiryWarning, setSessionExpiryWarning] = useState(false);

  // --- auth ---
  const login = useCallback((phone: string, pin: string): boolean => {
    const s = staffList.find(st => st.phone === phone && st.pin === pin && st.active);
    if (s) {
      setCurrentUser(s);
      setAuditLog(prev => [{ id:`al-${Date.now()}`,action:`${s.name} logged in`,user:s.name,time:now(),type:'login' }, ...prev]);
      return true;
    }
    return false;
  }, [staffList]);

  const logout = useCallback(() => {
    setCurrentUser(null);
    setCart([]);
    setScreen('dashboard');
  }, []);

  const hasPermission = useCallback((perm: Permission): boolean => {
    if (!currentUser) return false;
    return ROLE_PERMISSIONS[currentUser.role].includes(perm);
  }, [currentUser]);

  const canAccessScreen = useCallback((s: Screen): boolean => {
    return hasPermission(s as Permission);
  }, [hasPermission]);

  // --- audit ---
  const addAudit = useCallback((action: string, type: AuditEntry['type']) => {
    const user = currentUser?.name ?? 'System';
    setAuditLog(prev => [{ id:`al-${Date.now()}`,action,user,time:now(),type }, ...prev]);
  }, [currentUser]);

  // --- POS / cart ---
  const activeTill = useMemo(() => tills.find(t => t.id === activeTillId) ?? tills[0], [tills, activeTillId]);

  const scanBarcode = useCallback((code: string): Product | null => {
    // scale barcodes start with 20 and encode weight
    if (code.startsWith('20') && code.length >= 8) {
      const productId = code.slice(2, 7);
      const weightStr = code.slice(7);
      const product = products.find(p => p.barcode.startsWith('20') && p.id === `p${parseInt(productId)}`);
      if (product) return product;
    }
    return products.find(p => p.barcode === code) ?? null;
  }, [products]);

  const addToCart = useCallback((productId: string, qty?: number, weighedPrice?: number) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    const price = weighedPrice ?? product.price;
    const quantity = qty ?? 1;
    setCart(prev => {
      const existing = prev.find(i => i.productId === productId && !i.weighed);
      if (existing && !weighedPrice) {
        return prev.map(i => i.productId === productId ? { ...i, qty: i.qty + quantity } : i);
      }
      return [...prev, { productId, name: product.name, price, qty: quantity, unit: product.unit, discount: 0, weighed: !!weighedPrice }];
    });
  }, [products]);

  const updateCartQty = useCallback((productId: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.productId !== productId || i.weighed) return i;
      return { ...i, qty: Math.max(0, i.qty + delta) };
    }).filter(i => i.weighed || i.qty > 0));
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart(prev => prev.filter(i => i.productId !== productId));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const applyCartDiscount = useCallback((pct: number): { needsApproval: boolean } => {
    if (pct <= 0 || pct > 100) return { needsApproval: false };
    setCart(prev => prev.map(i => ({ ...i, discount: Math.round((i.price * i.qty * pct) / 100) })));
    if (pct > 10) {
      addAudit(`Applied ${pct}% discount (requires approval)`, 'discount');
      return { needsApproval: true };
    }
    addAudit(`Applied ${pct}% discount`, 'discount');
    return { needsApproval: false };
  }, [addAudit]);

  const holdSale = useCallback(() => {
    if (cart.length === 0) return;
    const total = cart.reduce((s, i) => s + i.price * i.qty - i.discount, 0);
    setHeldSales(prev => [...prev, { id:`held-${Date.now()}`,items:cart,time:now(),total }]);
    setCart([]);
  }, [cart]);

  const resumeSale = useCallback((id: string) => {
    const held = heldSales.find(h => h.id === id);
    if (!held) return;
    setCart(held.items);
    setHeldSales(prev => prev.filter(h => h.id !== id));
  }, [heldSales]);

  const deleteHeldSale = useCallback((id: string) => {
    setHeldSales(prev => prev.filter(h => h.id !== id));
  }, []);

  // --- payment validation & checkout ---
  const validatePayment = useCallback((method: string, details: { cashTendered?: number; mpesaPhone?: string; customerId?: string; cashAmount?: number; mpesaAmount?: number }): { valid: boolean; error?: string } => {
    const subtotal = cart.reduce((s, i) => s + i.price * i.qty - i.discount, 0);
    const taxableAmount = cart.filter(i => products.find(p => p.id === i.productId)?.taxable).reduce((s, i) => s + i.price * i.qty - i.discount, 0);
    const tax = Math.round(taxableAmount * 0.16);
    const total = subtotal + tax;

    if (method === 'cash') {
      if (!details.cashTendered || details.cashTendered < total) return { valid:false, error:'Cash tendered is less than total due' };
    }
    if (method === 'mpesa') {
      if (!details.mpesaPhone || details.mpesaPhone.length < 10) return { valid:false, error:'Valid M-Pesa phone number required' };
    }
    if (method === 'split') {
      const sum = (details.cashAmount ?? 0) + (details.mpesaAmount ?? 0);
      if (Math.abs(sum - total) > 1) return { valid:false, error:`Split amounts must equal ${total}. Currently: ${sum}` };
    }
    if (method === 'credit') {
      if (!details.customerId) return { valid:false, error:'Select a customer for credit sale' };
      const cust = customers.find(c => c.id === details.customerId);
      if (!cust) return { valid:false, error:'Invalid customer' };
      if (cust.debt + total > cust.creditLimit) return { valid:false, error:`Credit limit exceeded. Available: ${cust.creditLimit - cust.debt}` };
    }
    return { valid: true };
  }, [cart, products, customers]);

  const completeSale = useCallback((method: 'cash'|'mpesa'|'credit'|'split', details: { cashTendered?: number; mpesaPhone?: string; mpesaRef?: string; customerId?: string; cashAmount?: number; mpesaAmount?: number }): { success: boolean; receiptNo?: string; change?: number; error?: string } => {
    const validation = validatePayment(method, details);
    if (!validation.valid) return { success:false, error:validation.error };

    const subtotal = cart.reduce((s, i) => s + i.price * i.qty - i.discount, 0);
    const taxableAmount = cart.filter(i => products.find(p => p.id === i.productId)?.taxable).reduce((s, i) => s + i.price * i.qty - i.discount, 0);
    const tax = Math.round(taxableAmount * 0.16);
    const total = subtotal + tax;
    const cost = cart.reduce((s, i) => { const p = products.find(pr => pr.id === i.productId); return s + (p?.cost ?? 0) * i.qty; }, 0);
    const discountTotal = cart.reduce((s, i) => s + i.discount, 0);
    const receiptNo = `RCP-${String(++receiptCounter).padStart(6,'0')}`;
    const cust = details.customerId ? customers.find(c => c.id === details.customerId) : null;

    const txn: Transaction = {
      id:`tx-${Date.now()}`, receiptNo, time: now(), date: today(),
      cashierId: currentUser?.id ?? 'st1', cashier: currentUser?.name ?? 'System',
      tillId: activeTillId, tillName: activeTill.name,
      items: [...cart], total, subtotal, tax, discount: discountTotal,
      method, cashAmount: details.cashTendered ?? details.cashAmount,
      mpesaAmount: details.mpesaAmount, mpesaRef: details.mpesaRef,
      customer: cust?.name, customerId: cust?.id,
      status: 'completed', cost,
    };
    setTransactions(prev => [txn, ...prev]);

    // update till
    setTills(prev => prev.map(t => t.id === activeTillId ? {
      ...t,
      cashSales: t.cashSales + (method === 'cash' ? total : method === 'split' ? (details.cashAmount ?? 0) : 0),
      mpesaSales: t.mpesaSales + (method === 'mpesa' ? total : method === 'split' ? (details.mpesaAmount ?? 0) : 0),
      creditSales: t.creditSales + (method === 'credit' ? total : 0),
      transactions: t.transactions + 1,
    } : t));

    // reduce stock
    setProducts(prev => prev.map(p => {
      const cartItem = cart.find(i => i.productId === p.id);
      return cartItem ? { ...p, stock: p.stock - cartItem.qty } : p;
    }));

    // stock movements
    cart.forEach(item => {
      setStockMovements(prev => [{ id:`m-${Date.now()}-${item.productId}`,productId:item.productId,productName:item.name,type:'Sale',qty:-item.qty,user:currentUser?.name ?? 'System',time:now(),reason:'',approved:true }, ...prev]);
    });

    // customer debt & loyalty
    if (cust && method === 'credit') {
      setCustomers(prev => prev.map(c => c.id === cust.id ? { ...c, debt: c.debt + total, totalSpent: c.totalSpent + total, loyaltyPoints: c.loyaltyPoints + Math.floor(total / 100) } : c));
    } else if (cust) {
      setCustomers(prev => prev.map(c => c.id === cust.id ? { ...c, totalSpent: c.totalSpent + total, loyaltyPoints: c.loyaltyPoints + Math.floor(total / 100) } : c));
    }

    // mpesa reconciliation
    if (method === 'mpesa' || (method === 'split' && details.mpesaAmount)) {
      const ref = details.mpesaRef ?? `AUTO-${Date.now()}`;
      setMpesaPayments(prev => [{ id:`mp-${Date.now()}`,phone:details.mpesaPhone ?? '',amount:method==='mpesa'?total:(details.mpesaAmount??0),ref,time:now(),matched:true,transactionId:txn.id }, ...prev]);
    }

    // staff sales
    if (currentUser) {
      setStaffList(prev => prev.map(s => s.id === currentUser.id ? { ...s, salesToday: s.salesToday + total } : s));
    }

    addAudit(`Completed sale ${receiptNo} (${method}) — KSh ${total}`, 'approval');
    setCart([]);
    setSelectedCustomerId(null);

    const change = method === 'cash' ? (details.cashTendered ?? 0) - total : 0;
    return { success: true, receiptNo, change };
  }, [cart, products, customers, currentUser, activeTillId, activeTill, validatePayment, addAudit]);

  // --- refunds ---
  const processRefund = useCallback((txnId: string, amount: number, reason: string, needsApproval: boolean): { needsApproval: boolean; approved: boolean } => {
    const txn = transactions.find(t => t.id === txnId);
    if (!txn) return { needsApproval:false, approved:false };

    if (needsApproval && !hasPermission('approve')) {
      setApprovals(prev => [...prev, {
        id:`ap-${Date.now()}`, type:'refund', description:`Refund ${txn.receiptNo} — ${reason}`,
        amount, requestedBy: currentUser?.name ?? 'Unknown', requestedAt: now(),
        status:'pending', transactionId: txnId,
      }]);
      addAudit(`Refund request for ${txn.receiptNo} — pending approval`, 'refund');
      return { needsApproval: true, approved: false };
    }

    // execute refund
    setTransactions(prev => prev.map(t => t.id === txnId ? { ...t, status: 'partial_refund', refundAmount: amount } : t));
    // restore stock
    txn.items.forEach(item => {
      setProducts(prev => prev.map(p => p.id === item.productId ? { ...p, stock: p.stock + item.qty } : p));
      setStockMovements(prev => [{ id:`m-${Date.now()}-${item.productId}`,productId:item.productId,productName:item.name,type:'Return',qty:item.qty,user:currentUser?.name ?? 'System',time:now(),reason:`Refund: ${reason}`,approved:true }, ...prev]);
    });
    addAudit(`Refunded ${txn.receiptNo} — KSh ${amount} — ${reason}`, 'refund');
    return { needsApproval: false, approved: true };
  }, [transactions, currentUser, hasPermission, addAudit]);

  // --- void ---
  const voidTransaction = useCallback((txnId: string): { needsApproval: boolean; approved: boolean } => {
    const txn = transactions.find(t => t.id === txnId);
    if (!txn) return { needsApproval:false, approved:false };

    if (!hasPermission('void')) {
      setApprovals(prev => [...prev, {
        id:`ap-${Date.now()}`, type:'void', description:`Void ${txn.receiptNo}`,
        requestedBy: currentUser?.name ?? 'Unknown', requestedAt: now(),
        status:'pending', transactionId: txnId,
      }]);
      addAudit(`Void request for ${txn.receiptNo} — pending approval`, 'void');
      return { needsApproval: true, approved: false };
    }

    setTransactions(prev => prev.map(t => t.id === txnId ? { ...t, status:'voided', total:0 } : t));
    txn.items.forEach(item => {
      setProducts(prev => prev.map(p => p.id === item.productId ? { ...p, stock: p.stock + item.qty } : p));
    });
    setTills(prev => prev.map(t => t.id === txn.tillId ? { ...t, voids: t.voids + 1 } : t));
    addAudit(`Voided ${txn.receiptNo}`, 'void');
    return { needsApproval: false, approved: true };
  }, [transactions, currentUser, hasPermission, addAudit]);

  // --- approvals ---
  const approveRequest = useCallback((approvalId: string, approved: boolean) => {
    const ap = approvals.find(a => a.id === approvalId);
    if (!ap) return;
    setApprovals(prev => prev.map(a => a.id === approvalId ? { ...a, status: approved ? 'approved' : 'denied', approvedBy: currentUser?.name } : a));

    if (approved && ap.transactionId) {
      if (ap.type === 'refund') {
        const txn = transactions.find(t => t.id === ap.transactionId);
        if (txn) {
          setTransactions(prev => prev.map(t => t.id === txn.id ? { ...t, status:'refunded', refundAmount: ap.amount ?? t.total } : t));
          txn.items.forEach(item => {
            setProducts(prev => prev.map(p => p.id === item.productId ? { ...p, stock: p.stock + item.qty } : p));
          });
        }
      }
      if (ap.type === 'void') {
        const txn = transactions.find(t => t.id === ap.transactionId);
        if (txn) {
          setTransactions(prev => prev.map(t => t.id === txn.id ? { ...t, status:'voided', total:0 } : t));
          txn.items.forEach(item => {
            setProducts(prev => prev.map(p => p.id === item.productId ? { ...p, stock: p.stock + item.qty } : p));
          });
        }
      }
    }
    addAudit(`${approved ? 'Approved' : 'Denied'}: ${ap.description}`, 'approval');
  }, [approvals, transactions, currentUser, addAudit]);

  // --- till operations ---
  const openTill = useCallback((tillId: string, float: number): boolean => {
    if (!hasPermission('manage_till')) return false;
    if (!currentUser) return false;
    setTills(prev => prev.map(t => t.id === tillId ? {
      ...t, status:'open', openingFloat:float, cashierId:currentUser.id, cashier:currentUser.name,
      cashSales:0, mpesaSales:0, creditSales:0, transactions:0, voids:0, variance:0,
      cashDrops:[], paidOuts:[], openedAt: now(), closingFloat:null,
    } : t));
    setActiveTillId(tillId);
    addAudit(`Opened ${tills.find(t=>t.id===tillId)?.name} with float KSh ${float}`, 'till');
    return true;
  }, [currentUser, hasPermission, tills, addAudit]);

  const closeTill = useCallback((tillId: string, countedCash: number): { variance: number; expected: number } | null => {
    if (!hasPermission('manage_till')) return null;
    const till = tills.find(t => t.id === tillId);
    if (!till) return null;
    const expectedCash = till.openingFloat + till.cashSales;
    const variance = countedCash - expectedCash;
    setTills(prev => prev.map(t => t.id === tillId ? { ...t, status:'closed', closingFloat: countedCash, variance } : t));
    addAudit(`Closed ${till.name}. Expected: ${expectedCash}, Counted: ${countedCash}, Variance: ${variance}`, 'cash');
    return { variance, expected: expectedCash };
  }, [tills, hasPermission, addAudit]);

  const cashDrop = useCallback((tillId: string, amount: number): boolean => {
    if (amount <= 0) return false;
    const till = tills.find(t => t.id === tillId);
    if (!till) return false;
    setTills(prev => prev.map(t => t.id === tillId ? {
      ...t, cashDrops: [...t.cashDrops, { id:`cd-${Date.now()}`,tillId,amount,time:now(),acknowledged:false }],
    } : t));
    addAudit(`Cash drop KSh ${amount} from ${till.name}`, 'cash');
    return true;
  }, [tills, addAudit]);

  const acknowledgeDrop = useCallback((dropId: string) => {
    setTills(prev => prev.map(t => ({
      ...t,
      cashDrops: t.cashDrops.map(d => d.id === dropId ? { ...d, acknowledged: true, acknowledgedBy: currentUser?.name } : d),
    })));
  }, [currentUser]);

  const paidOut = useCallback((tillId: string, amount: number, reason: string): boolean => {
    if (amount <= 0 || !reason) return false;
    const till = tills.find(t => t.id === tillId);
    if (!till) return false;
    setTills(prev => prev.map(t => t.id === tillId ? {
      ...t, paidOuts: [...t.paidOuts, { id:`po-${Date.now()}`,tillId,amount,reason,time:now(),user:currentUser?.name ?? 'Unknown' }],
    } : t));
    addAudit(`Paid out KSh ${amount} from ${till.name} — ${reason}`, 'cash');
    return true;
  }, [tills, currentUser, addAudit]);

  // --- products ---
  const addProduct = useCallback((p: Omit<Product,'id'|'imageColor'>): void => {
    const id = `p${Date.now()}`;
    setProducts(prev => [...prev, { ...p, id, imageColor: colors[Math.floor(Math.random()*colors.length)] }]);
    addAudit(`Added product: ${p.name}`, 'price_change');
  }, [addAudit]);

  const updateProductPrice = useCallback((productId: string, newPrice: number, scheduled?: string): void => {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    if (newPrice < product.cost && !hasPermission('price_change')) {
      // below-cost alert — requires manager
      setApprovals(prev => [...prev, {
        id:`ap-${Date.now()}`, type:'price_change',
        description:`Below-cost price for ${product.name}: KSh ${newPrice} (cost: ${product.cost})`,
        requestedBy: currentUser?.name ?? 'Unknown', requestedAt: now(), status:'pending',
      }]);
      return;
    }
    if (scheduled) {
      setPriceChanges(prev => [...prev, { id:`pc-${Date.now()}`,productId,productName:product.name,oldPrice:product.price,newPrice,date:scheduled,user:currentUser?.name ?? 'System',scheduled,applied:false }]);
    } else {
      setProducts(prev => prev.map(p => p.id === productId ? { ...p, price: newPrice } : p));
      setPriceChanges(prev => [...prev, { id:`pc-${Date.now()}`,productId,productName:product.name,oldPrice:product.price,newPrice,date:today(),user:currentUser?.name ?? 'System',applied:true }]);
    }
    addAudit(`Price change: ${product.name} ${product.price} → ${newPrice}`, 'price_change');
  }, [products, currentUser, hasPermission, addAudit]);

  const applyMarkdown = useCallback((productId: string, markdownPct: number): void => {
    if (!hasPermission('markdown')) {
      const product = products.find(p => p.id === productId);
      setApprovals(prev => [...prev, {
        id:`ap-${Date.now()}`, type:'markdown',
        description:`Near-expiry markdown ${markdownPct}% for ${product?.name}`,
        requestedBy: currentUser?.name ?? 'Unknown', requestedAt: now(), status:'pending',
      }]);
      return;
    }
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, price: Math.round(p.price * (1 - markdownPct/100)) } : p));
    const product = products.find(p => p.id === productId);
    addAudit(`Markdown ${markdownPct}% applied to ${product?.name}`, 'price_change');
  }, [products, hasPermission, currentUser, addAudit]);

  // --- promotions ---
  const addPromotion = useCallback((promo: Omit<Promotion,'id'>): void => {
    setPromotions(prev => [...prev, { ...promo, id:`promo-${Date.now()}` }]);
    addAudit(`Created promotion: ${promo.name}`, 'price_change');
  }, [addAudit]);

  const togglePromotion = useCallback((promoId: string): void => {
    setPromotions(prev => prev.map(p => p.id === promoId ? { ...p, active: !p.active } : p));
  }, []);

  // --- inventory ---
  const submitStockAdjustment = useCallback((productId: string, qty: number, type: StockMovement['type'], reason: string): { needsApproval: boolean } => {
    const product = products.find(p => p.id === productId);
    if (!product || !reason) return { needsApproval: false };

    const needsApproval = Math.abs(qty) > 5 && !hasPermission('stock_adjust');
    if (needsApproval) {
      setApprovals(prev => [...prev, {
        id:`ap-${Date.now()}`, type:'stock_adjust',
        description:`Stock ${type}: ${product.name} (${qty > 0 ? '+' : ''}${qty}) — ${reason}`,
        requestedBy: currentUser?.name ?? 'Unknown', requestedAt: now(), status:'pending',
      }]);
      addAudit(`Stock adjustment request: ${product.name} (${qty})`, 'adjustment');
      return { needsApproval: true };
    }

    setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: Math.max(0, p.stock + qty) } : p));
    setStockMovements(prev => [{ id:`m-${Date.now()}`,productId,productName:product.name,type,qty,user:currentUser?.name ?? 'System',time:now(),reason,approved:true }, ...prev]);
    addAudit(`Stock ${type}: ${product.name} (${qty > 0 ? '+' : ''}${qty})`, 'adjustment');
    return { needsApproval: false };
  }, [products, hasPermission, currentUser, addAudit]);

  const updateStockTakeCount = useCallback((productId: string, countedQty: number): void => {
    setStockTake(prev => ({
      ...prev,
      items: prev.items.map(it => it.productId === productId ? { ...it, countedQty, variance: countedQty - it.systemQty } : it),
    }));
  }, []);

  const completeStockTake = useCallback((): { variances: number; adjusted: number } => {
    let adjusted = 0;
    const variances = stockTake.items.filter(it => it.countedQty !== null && it.countedQty !== it.systemQty).length;
    stockTake.items.forEach(it => {
      if (it.countedQty !== null && it.countedQty !== it.systemQty) {
        const diff = it.countedQty - it.systemQty;
        setProducts(prev => prev.map(p => p.id === it.productId ? { ...p, stock: it.countedQty! } : p));
        setStockMovements(prev => [{ id:`m-${Date.now()}-${it.productId}`,productId:it.productId,productName:it.productName,type:'Adjustment',qty:diff,user:currentUser?.name ?? 'System',time:now(),reason:'Stock take correction',approved:true }, ...prev]);
        adjusted++;
      }
    });
    setStockTake(prev => ({ ...prev, status:'completed' }));
    addAudit(`Completed stock take — ${variances} variances, ${adjusted} adjusted`, 'adjustment');
    return { variances, adjusted };
  }, [stockTake, currentUser, addAudit]);

  // --- suppliers / purchasing ---
  const addSupplier = useCallback((s: Omit<Supplier,'id'|'priceHistory'|'balance'|'lastOrder'|'products'>): void => {
    setSuppliers(prev => [...prev, { ...s, id:`s-${Date.now()}`,balance:0,lastOrder:'—',products:0,priceHistory:[] }]);
  }, []);

  const createPO = useCallback((supplierId: string, items: PurchaseOrderItem[], expected: string, paymentTerms: string): void => {
    const supplier = suppliers.find(s => s.id === supplierId);
    if (!supplier) return;
    const total = items.reduce((s, i) => s + i.total, 0);
    const poId = `PO-${String(purchaseOrders.length + 1).padStart(3,'0')}`;
    setPurchaseOrders(prev => [...prev, {
      id: poId, supplierId, supplierName: supplier.name, date: today(), expected,
      status: 'draft', total, items, paymentTerms, paymentStatus: 'unpaid',
    }]);
    addAudit(`Created ${poId} for ${supplier.name}`, 'approval');
  }, [suppliers, purchaseOrders.length, addAudit]);

  const sendPO = useCallback((poId: string): void => {
    setPurchaseOrders(prev => prev.map(p => p.id === poId ? { ...p, status:'sent' } : p));
    addAudit(`Sent ${poId} to supplier`, 'approval');
  }, [addAudit]);

  const receivePO = useCallback((poId: string, partial: boolean): void => {
    const po = purchaseOrders.find(p => p.id === poId);
    if (!po) return;
    setPurchaseOrders(prev => prev.map(p => p.id === poId ? { ...p, status: partial ? 'partial' : 'received' } : p));
    // update stock & supplier balance
    po.items.forEach(item => {
      setProducts(prev => prev.map(p => p.id === item.productId ? { ...p, stock: p.stock + item.qty } : p));
      setStockMovements(prev => [{ id:`m-${Date.now()}-${item.productId}`,productId:item.productId,productName:item.name,type:'Received',qty:item.qty,user:currentUser?.name ?? 'System',time:now(),reason:`${poId} delivery`,approved:true }, ...prev]);
    });
    setSuppliers(prev => prev.map(s => s.id === po.supplierId ? { ...s, balance: s.balance + po.total, lastOrder: today() } : s));
    addAudit(`Received ${poId} (${partial ? 'partial' : 'complete'})`, 'approval');
  }, [purchaseOrders, currentUser, addAudit]);

  const scheduleSupplierPayment = useCallback((poId: string, amount: number, dueDate: string): void => {
    const po = purchaseOrders.find(p => p.id === poId);
    if (!po) return;
    setPurchaseOrders(prev => prev.map(p => p.id === poId ? { ...p, paymentDue: dueDate, paymentStatus: amount >= po.total ? 'paid' : 'partial' } : p));
    if (amount > 0) {
      setSuppliers(prev => prev.map(s => s.id === po.supplierId ? { ...s, balance: Math.max(0, s.balance - amount) } : s));
    }
    addAudit(`Scheduled payment for ${poId}: KSh ${amount} due ${dueDate}`, 'cash');
  }, [purchaseOrders, addAudit]);

  const supplierReturn = useCallback((supplierId: string, productId: string, qty: number, reason: string): void => {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: Math.max(0, p.stock - qty) } : p));
    setStockMovements(prev => [{ id:`m-${Date.now()}`,productId,productName:product.name,type:'Transfer',qty:-qty,user:currentUser?.name ?? 'System',time:now(),reason:`Return to supplier: ${reason}`,approved:true }, ...prev]);
    const refund = qty * product.cost;
    setSuppliers(prev => prev.map(s => s.id === supplierId ? { ...s, balance: Math.max(0, s.balance - refund) } : s));
    addAudit(`Supplier return: ${qty}x ${product.name} — ${reason}`, 'approval');
  }, [products, currentUser, addAudit]);

  // --- customers ---
  const addCustomer = useCallback((c: Omit<Customer,'id'|'totalSpent'|'joinedDate'|'loyaltyPoints'|'debt'>): void => {
    setCustomers(prev => [...prev, { ...c, id:`c-${Date.now()}`,debt:0,totalSpent:0,joinedDate:today(),loyaltyPoints:0,loyaltyConsent:c.loyaltyConsent ?? false,whatsappConsent:c.whatsappConsent ?? false }]);
  }, []);

  const payDebt = useCallback((customerId: string, amount: number): void => {
    setCustomers(prev => prev.map(c => c.id === customerId ? { ...c, debt: Math.max(0, c.debt - amount) } : c));
    const cust = customers.find(c => c.id === customerId);
    addAudit(`Debt payment: ${cust?.name} — KSh ${amount}`, 'cash');
  }, [customers, addAudit]);

  // --- staff ---
  const addStaff = useCallback((s: { name: string; role: Role; phone: string; pin: string }): void => {
    setStaffList(prev => [...prev, { ...s, id:`st-${Date.now()}`,active:true,salesToday:0,attendance:'absent',twoFactor:false }]);
    addAudit(`Added staff: ${s.name} (${s.role})`, 'approval');
  }, [addAudit]);

  const toggleStaff2FA = useCallback((staffId: string): void => {
    setStaffList(prev => prev.map(s => s.id === staffId ? { ...s, twoFactor: !s.twoFactor } : s));
  }, []);

  const clockIn = useCallback((staffId: string): void => {
    setStaffList(prev => prev.map(s => s.id === staffId ? { ...s, attendance:'present', clockInTime: now() } : s));
  }, []);

  const clockOut = useCallback((staffId: string): void => {
    setStaffList(prev => prev.map(s => s.id === staffId ? { ...s, attendance:'absent', clockInTime: undefined } : s));
  }, []);

  // --- exchange ---
  const processExchange = useCallback((txnId: string, reason: string): { needsApproval: boolean; approved: boolean; items: CartItem[] } => {
    const txn = transactions.find(t => t.id === txnId);
    if (!txn) return { needsApproval: false, approved: false, items: [] };

    if (!hasPermission('approve')) {
      setApprovals(prev => [...prev, {
        id:`ap-${Date.now()}`, type:'refund', description:`Exchange ${txn.receiptNo} — ${reason}`,
        requestedBy: currentUser?.name ?? 'Unknown', requestedAt: now(),
        status:'pending', transactionId: txnId,
      }]);
      addAudit(`Exchange request for ${txn.receiptNo} — pending approval`, 'refund');
      return { needsApproval: true, approved: false, items: [] };
    }

    setTransactions(prev => prev.map(t => t.id === txnId ? { ...t, status: 'partial_refund' as const } : t));
    txn.items.forEach(item => {
      setProducts(prev => prev.map(p => p.id === item.productId ? { ...p, stock: p.stock + item.qty } : p));
      setStockMovements(prev => [{ id:`m-${Date.now()}-${item.productId}`,productId:item.productId,productName:item.name,type:'Return',qty:item.qty,user:currentUser?.name ?? 'System',time:now(),reason:`Exchange: ${reason}`,approved:true }, ...prev]);
    });
    addAudit(`Exchange approved for ${txn.receiptNo} — ${reason}`, 'refund');
    return { needsApproval: false, approved: true, items: txn.items };
  }, [transactions, currentUser, hasPermission, addAudit]);

  // --- computed ---
  const lowStockProducts = useMemo(() => products.filter(p => p.stock <= p.reorderLevel), [products]);
  const expiringProducts = useMemo(() => products.filter(p => {
    if (!p.expiry) return false;
    const days = (new Date(p.expiry).getTime() - new Date('2026-10-08').getTime()) / (1000*60*60*24);
    return days <= 7;
  }), [products]);

  const categories = useMemo(() => [...new Set(products.map(p => p.category))].sort(), [products]);
  const departments = useMemo(() => [...new Set(products.map(p => p.department))].sort(), [products]);

  const todaySales = useMemo(() => {
    const todayTxns = transactions.filter(t => t.status === 'completed');
    const total = todayTxns.reduce((s, t) => s + t.total, 0);
    const cashTotal = todayTxns.reduce((s, t) => s + (t.cashAmount ?? (t.method === 'cash' ? t.total : 0)), 0);
    const mpesaTotal = todayTxns.reduce((s, t) => s + (t.mpesaAmount ?? (t.method === 'mpesa' ? t.total : 0)), 0);
    const creditTotal = todayTxns.reduce((s, t) => s + (t.method === 'credit' ? t.total : 0), 0);
    const totalCost = todayTxns.reduce((s, t) => s + t.cost, 0);
    return { total, count: todayTxns.length, cashTotal, mpesaTotal, creditTotal, grossProfit: total - totalCost };
  }, [transactions]);

  const topProducts = useMemo(() => {
    const counts: Record<string, number> = {};
    transactions.filter(t => t.status === 'completed').forEach(txn => {
      txn.items.forEach(item => { counts[item.productId] = (counts[item.productId] ?? 0) + item.qty; });
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([id, qty]) => ({ product: products.find(p => p.id === id), qty }))
      .filter(e => e.product);
  }, [transactions, products]);

  const weeklySalesData = useMemo(() => {
    const days: { date: string; label: string; totalSales: number; transactions: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date('2026-10-08');
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayTxns = transactions.filter(t => t.date === dateStr && t.status === 'completed');
      const totalSales = dayTxns.reduce((s, t) => s + t.total, 0);
      const label = d.toLocaleDateString('en-US', { weekday: 'short' });
      days.push({ date: dateStr, label, totalSales, transactions: dayTxns.length });
    }
    return days;
  }, [transactions]);

  const pendingApprovals = useMemo(() => approvals.filter(a => a.status === 'pending'), [approvals]);

  // --- expanded feature actions ---
  const t = useCallback((key: string): string => translations[language][key] ?? key, [language]);

  const completeOwnerSetup = useCallback((name: string, phone: string, pin: string): void => {
    setSetupComplete(true);
    addAudit(`Owner setup completed for ${name}`, 'login');
  }, [addAudit]);

  const enrollAuthenticator = useCallback((): void => {
    setAuthenticatorEnrolled(true);
    addAudit('Authenticator enrolled', 'login');
  }, [addAudit]);

  const verifyAuthenticator = useCallback((code: string): boolean => {
    if (code.length === 6) {
      addAudit('Authenticator verified', 'login');
      return true;
    }
    return false;
  }, [addAudit]);

  const approveDevice = useCallback((deviceId: string): void => {
    setDevices(prev => prev.map(d => d.id === deviceId ? { ...d, approved: true, status: 'Active' as const } : d));
    addAudit(`Device approved`, 'login');
  }, [addAudit]);

  const revokeDevice = useCallback((deviceId: string): void => {
    setDevices(prev => prev.filter(d => d.id !== deviceId));
    addAudit(`Device revoked`, 'login');
  }, [addAudit]);

  // product image upload
  const uploadProductImage = useCallback((productId: string, imageUrl: string): void => {
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, imageUrl } : p));
  }, []);

  // import/export preview
  const parseImportData = useCallback((rows: string[][]): void => {
    const parsed: ImportExportRow[] = rows.map((row, i) => {
      const errors: string[] = [];
      if (!row[0]) errors.push('Missing name');
      if (!row[1]) errors.push('Missing barcode');
      const price = parseFloat(row[2]);
      if (isNaN(price)) errors.push('Invalid price');
      return { row: i + 1, data: { name: row[0], barcode: row[1], price: row[2], category: row[3] ?? '', department: row[4] ?? '' }, errors, valid: errors.length === 0 };
    });
    setImportPreview(parsed);
  }, []);

  const confirmImport = useCallback((): { imported: number; errors: number } => {
    const valid = importPreview.filter(r => r.valid);
    valid.forEach(row => {
      const id = `p${Date.now()}-${row.row}`;
      setProducts(prev => [...prev, {
        id, name: row.data.name, barcode: row.data.barcode, category: row.data.category || 'Uncategorized',
        department: row.data.department || 'Grocery', price: parseFloat(row.data.price), cost: 0,
        unit: 'each', stock: 0, reorderLevel: 10, taxable: true, imageColor: colors[Math.floor(Math.random()*colors.length)],
      }]);
    });
    const imported = valid.length;
    const errors = importPreview.length - valid.length;
    setImportPreview([]);
    addAudit(`Imported ${imported} products (${errors} errors)`, 'price_change');
    return { imported, errors };
  }, [importPreview, addAudit]);

  // expenses
  const addExpense = useCallback((e: Omit<Expense, 'id' | 'status'>): { needsApproval: boolean } => {
    const needsApproval = e.amount > 50000 && !hasPermission('approve');
    if (needsApproval) {
      setExpenses(prev => [...prev, { ...e, id: `e-${Date.now()}`, status: 'pending' }]);
      setApprovals(prev => [...prev, {
        id: `ap-${Date.now()}`, type: 'expense', description: `Expense: ${e.description} — TSh ${e.amount}`,
        amount: e.amount, requestedBy: e.user, requestedAt: now(), status: 'pending',
      }]);
      addAudit(`Expense request: ${e.description} (TSh ${e.amount})`, 'expense');
      return { needsApproval: true };
    }
    setExpenses(prev => [...prev, { ...e, id: `e-${Date.now()}`, status: 'approved' }]);
    addAudit(`Expense recorded: ${e.description} (TSh ${e.amount})`, 'expense');
    return { needsApproval: false };
  }, [hasPermission, addAudit]);

  const approveExpense = useCallback((expenseId: string, approved: boolean): void => {
    setExpenses(prev => prev.map(e => e.id === expenseId ? { ...e, status: approved ? 'approved' : 'denied', approvedBy: currentUser?.name } : e));
    addAudit(`${approved ? 'Approved' : 'Denied'} expense`, 'expense');
  }, [currentUser, addAudit]);

  // banking
  const addBankAccount = useCallback((a: Omit<BankAccount, 'id' | 'balance' | 'entries'>): void => {
    setBankAccounts(prev => [...prev, { ...a, id: `b-${Date.now()}`, balance: 0, entries: [] }]);
    addAudit(`Added bank account: ${a.name}`, 'expense');
  }, [addAudit]);

  const importBankStatement = useCallback((accountId: string, entries: Omit<BankEntry, 'id' | 'reconciled'>[]): void => {
    setBankAccounts(prev => prev.map(a => a.id === accountId ? {
      ...a,
      entries: [...a.entries, ...entries.map(e => ({ ...e, id: `be-${Date.now()}-${Math.random()}`, reconciled: false, imported: true }))],
    } : a));
    addAudit(`Imported ${entries.length} bank statement entries`, 'expense');
  }, [addAudit]);

  const reconcileBankEntry = useCallback((accountId: string, entryId: string): void => {
    setBankAccounts(prev => prev.map(a => a.id === accountId ? {
      ...a,
      entries: a.entries.map(e => e.id === entryId ? { ...e, reconciled: true } : e),
    } : a));
  }, []);

  // messaging
  const sendMessage = useCallback((msg: Omit<MessageLog, 'id' | 'time' | 'status'>): { status: 'sent' | 'failed' | 'uncertain' } => {
    const isOnline = onlineStatus === 'online';
    const status = isOnline ? 'sent' : 'uncertain';
    setMessageLog(prev => [{ ...msg, id: `ml-${Date.now()}`, time: now(), status }, ...prev]);
    addAudit(`Sent ${msg.type} to ${msg.recipientName}`, 'messaging');
    return { status };
  }, [onlineStatus, addAudit]);

  const updateNotificationSettings = useCallback((settings: Partial<NotificationSetting>): void => {
    setNotificationSettings(prev => ({ ...prev, ...settings }));
  }, []);

  // offline
  const goOffline = useCallback((): void => { setOnlineStatus('offline'); }, []);
  const goOnline = useCallback((): void => {
    setOnlineStatus('syncing');
    setTimeout(() => {
      setOnlineStatus('online');
      setOfflineOps(prev => prev.map(op => ({ ...op, status: 'synced' as const })));
      addAudit('Synced offline operations', 'offline');
    }, 1500);
  }, [addAudit]);

  const addOfflineOp = useCallback((op: Omit<OfflineOperation, 'id' | 'time' | 'retryCount'>): void => {
    setOfflineOps(prev => [...prev, { ...op, id: `off-${Date.now()}`, time: now(), retryCount: 0 }]);
  }, []);

  const retryOfflineOp = useCallback((opId: string): void => {
    setOfflineOps(prev => prev.map(op => op.id === opId ? { ...op, status: 'synced' as const, retryCount: op.retryCount + 1 } : op));
  }, []);

  const resolveConflict = useCallback((opId: string, action: 'accept' | 'discard'): void => {
    setOfflineOps(prev => action === 'discard'
      ? prev.filter(op => op.id !== opId)
      : prev.map(op => op.id === opId ? { ...op, status: 'synced' as const } : op));
    addAudit(`Offline conflict ${action === 'discard' ? 'discarded' : 'resolved'}`, 'offline');
  }, [addAudit]);

  // suspicious activity & thresholds
  const updateLossThresholds = useCallback((t: Partial<LossThreshold>): void => {
    setLossThresholds(prev => ({ ...prev, ...t }));
  }, []);

  const resolveSuspiciousActivity = useCallback((id: string): void => {
    setSuspiciousActivity(prev => prev.map(s => s.id === id ? { ...s, resolved: true } : s));
  }, []);

  // commissions
  const updateCommission = useCallback((staffId: string, rate: number, target: number): void => {
    setCommissions(prev => prev.map(c => c.staffId === staffId ? { ...c, rate, target } : c));
  }, []);

  // incentives
  const addIncentive = useCallback((inc: Omit<Incentive, 'id'>): void => {
    setIncentives(prev => [...prev, { ...inc, id: `inc-${Date.now()}` }]);
  }, []);

  const toggleIncentive = useCallback((id: string): void => {
    setIncentives(prev => prev.map(i => i.id === id ? { ...i, active: !i.active } : i));
  }, []);

  // admin
  const addAdminClient = useCallback((c: Omit<AdminClient, 'id' | 'createdAt'>): void => {
    setAdminClients(prev => [...prev, { ...c, id: `ac-${Date.now()}`, createdAt: today() }]);
    addAudit(`Onboarded client: ${c.businessName}`, 'admin');
  }, [addAudit]);

  const updateAdminClient = useCallback((id: string, updates: Partial<AdminClient>): void => {
    setAdminClients(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  }, []);

  // loyalty
  const redeemLoyaltyPoints = useCallback((customerId: string, points: number): { success: boolean; error?: string } => {
    const cust = customers.find(c => c.id === customerId);
    if (!cust) return { success: false, error: 'Customer not found' };
    if (cust.loyaltyPoints < points) return { success: false, error: 'Insufficient points' };
    setCustomers(prev => prev.map(c => c.id === customerId ? { ...c, loyaltyPoints: c.loyaltyPoints - points } : c));
    addAudit(`Redeemed ${points} loyalty points for ${cust.name}`, 'approval');
    return { success: true };
  }, [customers, addAudit]);

  const setLoyaltyConsent = useCallback((customerId: string, consent: boolean): void => {
    setCustomers(prev => prev.map(c => c.id === customerId ? { ...c, loyaltyConsent: consent } : c));
  }, []);

  // supplier statements
  const recordSupplierPayment = useCallback((supplierId: string, amount: number, method: string): void => {
    setSuppliers(prev => prev.map(s => s.id === supplierId ? {
      ...s,
      balance: Math.max(0, s.balance - amount),
      statements: [...(s.statements ?? []), { id: `st-${Date.now()}`, date: today(), description: `Payment via ${method}`, debit: 0, credit: amount, balance: Math.max(0, s.balance - amount) }],
    } : s));
    addAudit(`Supplier payment: TSh ${amount} to ${suppliers.find(s=>s.id===supplierId)?.name}`, 'cash');
  }, [suppliers, addAudit]);

  // staff notifications
  const markNotificationRead = useCallback((staffId: string, notifId: string): void => {
    setStaffList(prev => prev.map(s => s.id === staffId ? {
      ...s,
      notifications: s.notifications?.map(n => n.id === notifId ? { ...n, read: true } : n),
    } : s));
  }, []);

  const pushNotification = useCallback((staffId: string, notif: { title: string; message: string; type: 'approval' | 'system' | 'incentive' }): void => {
    setStaffList(prev => prev.map(s => s.id === staffId ? {
      ...s,
      notifications: [...(s.notifications ?? []), { id: `n-${Date.now()}`, ...notif, time: now(), read: false }],
    } : s));
  }, []);

  return {
    // state
    currentUser, screen, products, customers, suppliers, purchaseOrders, staffList,
    tills, transactions, approvals, stockMovements, priceChanges, promotions, auditLog,
    mpesaPayments, heldSales, stockTake, cart, selectedCustomerId, activeTillId, activeTill,
    lowStockProducts, expiringProducts, categories, departments, todaySales, pendingApprovals, topProducts, weeklySalesData,
    // new state
    language, bankAccounts, expenses, messageLog, notificationSettings, offlineOps, onlineStatus,
    suspiciousActivity, lossThresholds, commissions, incentives, adminClients, devices,
    importPreview, setupComplete, authenticatorEnrolled, sessionExpiryWarning,
    // actions
    setScreen, login, logout, hasPermission, canAccessScreen,
    scanBarcode, addToCart, updateCartQty, removeFromCart, clearCart,
    applyCartDiscount, holdSale, resumeSale, deleteHeldSale,
    validatePayment, completeSale, processRefund, processExchange, voidTransaction, approveRequest,
    openTill, closeTill, cashDrop, acknowledgeDrop, paidOut,
    addProduct, updateProductPrice, applyMarkdown, addPromotion, togglePromotion,
    submitStockAdjustment, updateStockTakeCount, completeStockTake,
    addSupplier, createPO, sendPO, receivePO, scheduleSupplierPayment, supplierReturn,
    addCustomer, payDebt, addStaff, toggleStaff2FA, clockIn, clockOut,
    setSelectedCustomerId, setActiveTillId,
    // new actions
    setLanguage, t,
    completeOwnerSetup, enrollAuthenticator, verifyAuthenticator, approveDevice, revokeDevice,
    uploadProductImage, parseImportData, confirmImport,
    addExpense, approveExpense,
    addBankAccount, importBankStatement, reconcileBankEntry,
    sendMessage, updateNotificationSettings,
    goOffline, goOnline, addOfflineOp, retryOfflineOp, resolveConflict,
    updateLossThresholds, resolveSuspiciousActivity,
    updateCommission, addIncentive, toggleIncentive,
    addAdminClient, updateAdminClient,
    redeemLoyaltyPoints, setLoyaltyConsent,
    recordSupplierPayment,
    markNotificationRead, pushNotification,
  };
}

export type Store = ReturnType<typeof useStore>;

export const formatKES = (amount: number): string =>
  'TSh ' + Math.round(amount).toLocaleString('en-KE', { minimumFractionDigits: 0, maximumFractionDigits: 0 });

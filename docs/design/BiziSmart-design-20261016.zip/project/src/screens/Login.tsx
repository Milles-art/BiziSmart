import { useState, useEffect } from 'react';
import { Store, Phone, KeyRound, AlertCircle, Lock, Shield, Smartphone, CheckCircle, Clock, Monitor, Tablet, UserPlus, ChevronRight } from 'lucide-react';
import type { Store as StoreType } from '@/store/useStore';

interface Props {
  store: StoreType;
}

type LoginMode = 'signin' | 'owner_setup' | 'authenticator' | 'device_approval' | 'temp_pin' | 'session_expired';

export function Login({ store }: Props) {
  const [mode, setMode] = useState<LoginMode>('signin');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // owner setup
  const [setupName, setSetupName] = useState('');
  const [setupPhone, setSetupPhone] = useState('');
  const [setupPin, setSetupPin] = useState('');
  const [setupPinConfirm, setSetupPinConfirm] = useState('');
  const [setupError, setSetupError] = useState('');

  // authenticator
  const [authCode, setAuthCode] = useState('');
  const [authError, setAuthError] = useState('');

  // temp pin
  const [tempPin, setTempPin] = useState('');
  const [tempPinConfirm, setTempPinConfirm] = useState('');
  const [tempNotice, setTempNotice] = useState('');

  const handleLogin = () => {
    setError('');
    setLoading(true);
    setTimeout(() => {
      const success = store.login(phone, pin);
      if (!success) {
        setError('Invalid phone number or PIN. Please try again.');
        setLoading(false);
      } else if (store.currentUser?.role === 'Owner' && !store.authenticatorEnrolled) {
        setMode('authenticator');
        setLoading(false);
      }
    }, 400);
  };

  const handleSetup = () => {
    setSetupError('');
    if (!setupName || !setupPhone || !setupPin) { setSetupError('All fields are required'); return; }
    if (setupPin.length !== 4) { setSetupError('PIN must be 4 digits'); return; }
    if (setupPin !== setupPinConfirm) { setSetupError('PINs do not match'); return; }
    store.completeOwnerSetup(setupName, setupPhone, setupPin);
    setMode('authenticator');
  };

  const handleAuthVerify = () => {
    setAuthError('');
    if (authCode.length !== 6) { setAuthError('Enter the 6-digit code from your authenticator app'); return; }
    const ok = store.verifyAuthenticator(authCode);
    if (ok) {
      store.enrollAuthenticator();
      setMode('temp_pin');
    } else {
      setAuthError('Invalid code. Please try again.');
    }
  };

  const handleTempPin = () => {
    if (tempPin.length !== 4 || tempPin !== tempPinConfirm) { setTempNotice('PINs do not match or are not 4 digits'); return; }
    setTempNotice('PIN changed successfully. You can now sign in.');
    setTimeout(() => { setMode('signin'); setTempNotice(''); }, 2000);
  };

  // session expiry simulation
  useEffect(() => {
    if (mode === 'session_expired') {
      const timer = setTimeout(() => setMode('signin'), 4000);
      return () => clearTimeout(timer);
    }
  }, [mode]);

  const pendingDevice = store.devices.find(d => d.status === 'Pending');

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500 shadow-lg shadow-emerald-500/30">
            <Store className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">BiziSmart</h1>
          <p className="text-sm text-slate-400">Supermarket POS System</p>
        </div>

        {/* Sign In */}
        {mode === 'signin' && (
          <div className="rounded-2xl bg-white p-7 shadow-2xl">
            <h2 className="mb-1 text-lg font-bold text-slate-800">Sign In</h2>
            <p className="mb-5 text-sm text-slate-500">Enter your phone number and PIN to continue</p>

            {error && <div className="mb-4 flex items-center gap-2 rounded-lg bg-red-50 p-3 text-sm text-red-600"><AlertCircle className="h-4 w-4 shrink-0" />{error}</div>}

            <div className="space-y-4">
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-500">Phone Number</label>
                <div className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2.5 focus-within:border-emerald-400">
                  <Phone className="h-4 w-4 text-slate-400" />
                  <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="0712345678" className="flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-300" onKeyDown={(e) => e.key === 'Enter' && handleLogin()} />
                </div>
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-500">4-digit PIN</label>
                <div className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2.5 focus-within:border-emerald-400">
                  <KeyRound className="h-4 w-4 text-slate-400" />
                  <input type="password" maxLength={4} value={pin} onChange={(e) => setPin(e.target.value)} placeholder="••••" className="flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-300" onKeyDown={(e) => e.key === 'Enter' && handleLogin()} />
                </div>
              </div>
            </div>

            <button onClick={handleLogin} disabled={loading || !phone || !pin} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white transition-all hover:bg-emerald-600 disabled:cursor-not-allowed disabled:opacity-40">
              {loading ? <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" /> : <><Lock className="h-4 w-4" /> Sign In</>}
            </button>

            <div className="mt-5 space-y-2">
              <button onClick={() => setMode('owner_setup')} className="flex w-full items-center justify-center gap-2 rounded-lg bg-slate-100 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-200">
                <UserPlus className="h-4 w-4" /> Owner Invitation Setup
              </button>
              {pendingDevice && (
                <button onClick={() => setMode('device_approval')} className="flex w-full items-center justify-center gap-2 rounded-lg bg-amber-50 py-2.5 text-sm font-medium text-amber-600 hover:bg-amber-100">
                  <Smartphone className="h-4 w-4" /> Device Approval Pending
                </button>
              )}
              <button onClick={() => setMode('session_expired')} className="text-xs text-slate-400 hover:text-slate-600">Session expired? Reconnect</button>
            </div>


          </div>
        )}

        {/* Owner Setup */}
        {mode === 'owner_setup' && (
          <div className="rounded-2xl bg-white p-7 shadow-2xl">
            <div className="mb-4 flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-emerald-500" />
              <h2 className="text-lg font-bold text-slate-800">Owner Invitation Setup</h2>
            </div>
            <p className="mb-5 text-sm text-slate-500">You've been invited as the shop owner. Complete setup to activate your account.</p>

            {setupError && <div className="mb-4 flex items-center gap-2 rounded-lg bg-red-50 p-3 text-sm text-red-600"><AlertCircle className="h-4 w-4 shrink-0" />{setupError}</div>}

            <div className="space-y-4">
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-500">Full Name</label>
                <input type="text" value={setupName} onChange={(e) => setSetupName(e.target.value)} placeholder="John Mwangi" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-500">Phone Number</label>
                <input type="tel" value={setupPhone} onChange={(e) => setSetupPhone(e.target.value)} placeholder="0712345678" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-500">Create 4-digit PIN</label>
                <input type="password" maxLength={4} value={setupPin} onChange={(e) => setSetupPin(e.target.value)} placeholder="••••" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-500">Confirm PIN</label>
                <input type="password" maxLength={4} value={setupPinConfirm} onChange={(e) => setSetupPinConfirm(e.target.value)} placeholder="••••" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" />
              </div>
            </div>

            <button onClick={handleSetup} disabled={!setupName || !setupPhone || !setupPin} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white hover:bg-emerald-600 disabled:opacity-40">
              Continue to Authenticator <ChevronRight className="h-4 w-4" />
            </button>
            <button onClick={() => setMode('signin')} className="mt-3 w-full text-center text-xs text-slate-400 hover:text-slate-600">Back to sign in</button>
          </div>
        )}

        {/* Authenticator Enrollment */}
        {mode === 'authenticator' && (
          <div className="rounded-2xl bg-white p-7 shadow-2xl">
            <div className="mb-4 flex items-center gap-2">
              <Shield className="h-5 w-5 text-emerald-500" />
              <h2 className="text-lg font-bold text-slate-800">Authenticator Enrollment</h2>
            </div>
            <div className="mb-5 rounded-xl bg-slate-50 p-4 text-center">
              <div className="mx-auto mb-3 flex h-32 w-32 items-center justify-center rounded-xl border-2 border-dashed border-slate-300 bg-white">
                <div className="grid grid-cols-8 gap-px">
                  {Array.from({ length: 64 }).map((_, i) => (
                    <div key={i} className={`h-2 w-2 ${Math.random() > 0.5 ? 'bg-slate-800' : 'bg-white'}`} />
                  ))}
                </div>
              </div>
              <p className="text-xs text-slate-500">Scan this QR code with Google Authenticator, Authy, or any TOTP app</p>
              <p className="mt-1 font-mono text-sm font-bold text-slate-700">JBSWY3DPEHPK3PXP</p>
            </div>

            {authError && <div className="mb-4 flex items-center gap-2 rounded-lg bg-red-50 p-3 text-sm text-red-600"><AlertCircle className="h-4 w-4 shrink-0" />{authError}</div>}

            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">Enter 6-digit verification code</label>
              <input type="text" maxLength={6} value={authCode} onChange={(e) => setAuthCode(e.target.value.replace(/\D/g, ''))} placeholder="000000" className="w-full rounded-lg border-2 border-slate-200 px-4 py-3 text-center text-2xl font-bold tracking-[0.5em] text-slate-800 outline-none focus:border-emerald-400" />
            </div>

            <button onClick={handleAuthVerify} disabled={authCode.length !== 6} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white hover:bg-emerald-600 disabled:opacity-40">
              <CheckCircle className="h-4 w-4" /> Verify & Continue
            </button>
            <button onClick={() => setMode('signin')} className="mt-3 w-full text-center text-xs text-slate-400 hover:text-slate-600">Skip for now</button>
          </div>
        )}

        {/* Temporary PIN Change */}
        {mode === 'temp_pin' && (
          <div className="rounded-2xl bg-white p-7 shadow-2xl">
            <div className="mb-4 flex items-center gap-2">
              <KeyRound className="h-5 w-5 text-amber-500" />
              <h2 className="text-lg font-bold text-slate-800">Change Temporary PIN</h2>
            </div>
            <p className="mb-5 text-sm text-slate-500">Your account was set up with a temporary PIN. Please create a new PIN to secure your account.</p>

            {tempNotice && <div className="mb-4 flex items-center gap-2 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-600"><CheckCircle className="h-4 w-4" />{tempNotice}</div>}

            <div className="space-y-4">
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-500">New 4-digit PIN</label>
                <input type="password" maxLength={4} value={tempPin} onChange={(e) => setTempPin(e.target.value)} placeholder="••••" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-500">Confirm New PIN</label>
                <input type="password" maxLength={4} value={tempPinConfirm} onChange={(e) => setTempPinConfirm(e.target.value)} placeholder="••••" className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-emerald-400" />
              </div>
            </div>

            <button onClick={handleTempPin} disabled={!tempPin || !tempPinConfirm} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white hover:bg-emerald-600 disabled:opacity-40">
              <Lock className="h-4 w-4" /> Change PIN
            </button>
          </div>
        )}

        {/* Session Expired */}
        {mode === 'session_expired' && (
          <div className="rounded-2xl bg-white p-7 shadow-2xl text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-100">
              <Clock className="h-8 w-8 text-amber-600" />
            </div>
            <h2 className="text-lg font-bold text-slate-800">Session Expired</h2>
            <p className="mt-2 text-sm text-slate-500">Your session has expired due to inactivity. Redirecting to sign in...</p>
            <div className="mt-4 flex justify-center"><div className="h-5 w-5 animate-spin rounded-full border-2 border-emerald-200 border-t-emerald-500" /></div>
          </div>
        )}

        {/* Device Approval */}
        {mode === 'device_approval' && pendingDevice && (
          <div className="rounded-2xl bg-white p-7 shadow-2xl">
            <div className="mb-4 flex items-center gap-2">
              <Smartphone className="h-5 w-5 text-amber-500" />
              <h2 className="text-lg font-bold text-slate-800">Device Approval Required</h2>
            </div>
            <div className="mb-5 rounded-xl border border-amber-200 bg-amber-50 p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-amber-100"><Smartphone className="h-6 w-6 text-amber-600" /></div>
                <div>
                  <p className="text-sm font-semibold text-slate-700">{pendingDevice.name}</p>
                  <p className="text-xs text-slate-500">{pendingDevice.device} · {pendingDevice.lastActive}</p>
                </div>
              </div>
            </div>
            <p className="mb-5 text-sm text-slate-500">A new device is requesting access to your BiziSmart account. Approve only if you recognize this device.</p>

            <div className="flex gap-3">
              <button onClick={() => { store.revokeDevice(pendingDevice.id); setMode('signin'); }} className="flex-1 rounded-xl border border-slate-200 py-3 text-sm font-medium text-slate-600 hover:bg-slate-50">Deny</button>
              <button onClick={() => { store.approveDevice(pendingDevice.id); setMode('signin'); }} className="flex flex-[2] items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white hover:bg-emerald-600">
                <CheckCircle className="h-4 w-4" /> Approve Device
              </button>
            </div>
          </div>
        )}

        <p className="mt-4 text-center text-xs text-slate-500">BiziSmart Supermarket · English / Kiswahili</p>
      </div>
    </div>
  );
}
